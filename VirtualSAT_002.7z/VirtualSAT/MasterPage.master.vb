Option Explicit On
Option Strict On

Imports FuncionesCarrito
Imports FuncionesWeb
Imports System.Data
Imports SAT.Funciones.Validaciones
Imports SAT.HomeSiteBLL
Imports SAT
Imports System.Configuration


Public Class MasterPage
    Inherits System.Web.UI.MasterPage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Dim intUsuario As Integer = GetCodigoRegistroUsuario() 'Comment by test-kgc <<<<
        Dim intUsuario = 1234 ' Set value for test-kgc <<<<<
        If Not IsPostBack Then
            If intUsuario <> 0 Then
                Inicio(intUsuario)
            Else
                lnk1.Visible = True
                lnk2.Visible = False
            End If
        End If

    End Sub
    Private Sub Inicio(ByVal intUsuario As Integer)
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim strDocumento As String = ""
        Dim intTipoDocu As Integer = 0

        ds = Nothing
        '-- Comment-by-test-kgc
        'ds = oBLL.BuscarUsuarioWEBxCodigo(GetConexionSoporteWEB, intUsuario)
        'If ds.Tables(0).Rows.Count > 0 Then
        '    With ds.Tables(0).Rows(0)
        '        strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
        '        strDocumento = CheckStr(.Item("VNRODOC"))
        '        intTipoDocu = CheckInt(.Item("TIPODOCEQ"))
        '    End With
        'End If
        '-----
        ds = Nothing
        oBLL = Nothing

        If strUsuario = "" Then strUsuario = "Invitado" ' add-by-test-kgc

        BuscarContribuyente(strDocumento, intTipoDocu, strUsuario)

    End Sub
    Private Sub BuscarContribuyente(ByVal strDocumento As String, ByVal intTipoDocu As Integer, ByVal strNombrePersona As String)
        Dim oBLL As ConsultasVarias
        Dim objPorContactos As New SAT.WEB.BLL.PortalSAT.clsContactos
        Dim ds As New DataSet
        Dim dsPersonaDatosContacto As DataSet = Nothing
        Dim strCodPer As String = ""
        Dim strPaswd As String = ""
        Dim strTelCasa1 As String = ""
        Dim strTelMovil1 As String = ""
        Dim strEMail1 As String = ""

        Try

            oBLL = New ConsultasVarias

            '-------------------------------
            ds = oBLL.BuscarPersona(GetConexionSiatTributos, intTipoDocu, strDocumento)

            If Not ds Is Nothing Then
                If ds.Tables(0).Rows.Count > 0 Then
                    With ds.Tables(0).Rows(0)
                        strCodPer = CheckStr(.Item("iCodPer"))
                        strPaswd = CheckStr(.Item("vPasswd"))
                    End With


                    lnk1.Visible = True
                    lnk2.Visible = False

                Else
                    lnk1.Visible = False
                    lnk2.Visible = True
                End If
            Else
                lnk1.Visible = False
                lnk2.Visible = True
            End If

        Catch ex As Exception
            'SAT.Base.Web.App.Errores.Registrar(ex)

        Finally
            ds = Nothing
            dsPersonaDatosContacto = Nothing
            oBLL = Nothing
            objPorContactos = Nothing
        End Try
    End Sub
End Class