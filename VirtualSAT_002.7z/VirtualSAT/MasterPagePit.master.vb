Option Explicit On
Option Strict On

Imports FuncionesCarrito
Imports FuncionesWeb
Imports System.Data
Imports SAT.Funciones.Validaciones
Imports SAT.HomeSiteBLL

Public Class MasterPage
    Inherits System.Web.UI.MasterPage

   

End Class

