Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.HomeSiteBLL
Imports SAT.Funciones.Validaciones
Imports CaptchaDLL

Partial Class modulos_Capturas
    Inherits PageBase

    Private intCaptcha As Integer = 4

    Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Inicio()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
        End If
    End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing

        Me.lblTitulo.Text = "CAPTURA DE VEHICULOS"
        lblFecha.Text = ""
        lblMensajeVacio.Text = ""
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    Private Sub Buscar()
        Dim oBLL As New ConsultasVarias
        Dim dsPapel As DataSet
        Dim strPlaca As String
        Dim dateFecha As Date = Date.Today
        strPlaca = ValidaCadena(Me.txtPlaca.Text)
        Me.grdCapturas.DataSource = Nothing
        Me.grdCapturas.DataBind()
        If strPlaca.Length > 5 Then
            dsPapel = oBLL.BuscarCapturaOperativo(GetConexionSiatTransitoLinea, strPlaca)
            If Not dsPapel Is Nothing Then
                If dsPapel.Tables(0).Rows.Count > 0 Then
                    lblMensajeVacio.Text = "El veh�culo de placa " + strPlaca.ToUpper() + " TIENE ORDEN DE CAPTURA por los siguientes conceptos:"
                    Me.grdCapturas.DataSource = dsPapel.Tables(0)
                    Me.grdCapturas.DataBind()
                Else
                    lblMensajeVacio.Text = "El veh�culo de placa " + strPlaca.ToUpper() + " no tiene orden de captura en la provincia de Lima."
                End If
            End If
            oBLL = Nothing
        Else
            lblMensajeVacio.Text = "Verifique el n�mero de placa ingresado."
        End If
        lblFecha.Text = "Informe actualizado al " + dateFecha.AddDays(-1).ToShortDateString()
    End Sub
    Protected Sub grdCapturas_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdCapturas.PageIndexChanging
        grdCapturas.PageIndex = e.NewPageIndex
        Buscar()
    End Sub

    Protected Sub ibtnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    Protected Sub CaptchaContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CaptchaContinue.Click
        GestionarConsulta()
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    '''<summary>M�todo para validar el c�digo captcha.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Function fbln_ValidarCaptha() As Boolean
        Dim blnRespuesta As Boolean
        If Session("CaptchaImageText") IsNot Nothing AndAlso txtCaptcha.Text.ToLower() = Session("CaptchaImageText").ToString().ToLower() Then
            blnRespuesta = True
        Else
            Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
        End If
        Return blnRespuesta
    End Function

    '''<summary>M�todo para ejecutar las consultas en base al tipo de consulta.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Sub GestionarConsulta()
        If (Me.txtPlaca.Text.Length > 4) Then
            If fbln_ValidarCaptha() Then
                Me.lblMensajeCapcha.Text = Nothing
                Buscar()
            Else
                Me.lblMensajeCapcha.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
        Else
            Me.lblMensajeCapcha.Text = Resources.Parametros.strMsjPlacaIncorrecta
        End If
    End Sub
End Class
