﻿Option Explicit On
Option Strict On

Imports SAT
Imports SAT.Funciones.Validaciones
Imports System.Data
Imports FuncionesWeb
Imports SAT.HomeSiteBLL
Imports CaptchaDLL

Partial Class modulos_ConsultarPagos
    Inherits System.Web.UI.Page

    Private intCaptcha As Integer = 4

#Region "Metodo y Procedimiento"
    Private Sub LlenarCriterio()
        Dim dtDatos As DataTable
        Dim dvDatos As DataView
        Try
            dtDatos = New DataTable

            Using objBll As New ConsultasVarias
                dtDatos = objBll.ParametrosCriterios(GetConexionSiatTransito)
                dvDatos = New DataView(dtDatos)
                'dvDatos.RowFilter = " iValPar in (0) "
            End Using
            SetCombo(dvDatos.ToTable.Copy, "iValPar", "vValPar", ddlCriterio, True)
        Catch ex As Exception

        End Try
    End Sub
#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ValidarPagina()
        If Not IsPostBack Then
            Inicio()
            LlenarCriterio()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
            Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)

        End If
    End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing
    End Sub

    Private Sub pBuscar()
        Dim dtDatos As DataTable
        Dim shtCriterio As Short = 0
        Dim strValor As String = String.Empty
        Try
            dtDatos = New DataTable
            shtCriterio = CShort(ddlCriterio.SelectedValue)
            strValor = txtValor.Text.Trim
            Using objBLL As New ConsultasVarias
                dtDatos = objBLL.BuscarDetallePago(GetConexionConsultaPagos, CShort(GetMuniID()), strValor, shtCriterio)
                'dtDatos = objBLL.BuscarDetallePagoLiquidacion(GetConexionSiatTransito, CShort(GetMuniID()), strValor)
            End Using
            grdPagos.DataSource = dtDatos
            grdPagos.DataBind()
        Catch ex As Exception
            Throw ex
        End Try
    End Sub

    Protected Sub ddlCriterio_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ddlCriterio.SelectedIndexChanged
        ' If txtValor.Text.Trim.Length > 0 Then txtValor.Text = String.Empty
        grdPagos.DataSource = Nothing
        grdPagos.DataBind()

    End Sub

    Protected Sub grdPagos_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdPagos.PageIndexChanging
        Me.grdPagos.PageIndex = e.NewPageIndex
        pBuscar()
    End Sub

    Protected Sub ibtnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    Protected Sub CaptchaContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CaptchaContinue.Click
        GestionarConsulta()
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    '''<summary>Método para validar el código captcha.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Function fbln_ValidarCaptha() As Boolean
        Dim blnRespuesta As Boolean
        If Session("CaptchaImageText") IsNot Nothing AndAlso txtCaptcha.Text.ToLower() = Session("CaptchaImageText").ToString().ToLower() Then
            blnRespuesta = True
        Else
            Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
        End If
        Return blnRespuesta
    End Function

    '''<summary>Método para ejecutar las consultas en base al tipo de consulta.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu>04/10/2017</FecActu></item>
    '''<item><Resp>Lucar Capristano</Resp></item>
    '''<item><Mot>Se agrega validación para consultas por Número de Operación</Mot></item></list></remarks>
    Private Sub GestionarConsulta()
        Dim shtCriterio As Short = 0
        shtCriterio = CShort(ddlCriterio.SelectedValue)
        grdPagos.DataSource = Nothing
        grdPagos.DataBind()

        If txtValor.Text.Trim.Length > 0 And shtCriterio >= 0 Then
            If (shtCriterio = CInt(Resources.Parametros.intCriterioNroOperacion)) Then
                If (IsNumeric(txtValor.Text)) Then
                    If (Convert.ToInt64(txtValor.Text.Trim) <= Convert.ToInt64(Resources.Parametros.intValorMaximoInt)) Then
                        If fbln_ValidarCaptha() Then
                            lblMensajeCapcha.Text = Nothing
                            pBuscar() '<<<<<<<<<<<<<<<<
                        Else
                            lblMensajeCapcha.Text = Resources.Parametros.strMsjAlertaCapcha
                        End If
                    Else
                        lblMensajeCapcha.Text = Resources.Parametros.strMsjValorInvalido
                    End If
                Else
                    lblMensajeCapcha.Text = Resources.Parametros.strMsjValorInvalido
                End If
            Else
                If fbln_ValidarCaptha() Then
                    lblMensajeCapcha.Text = Nothing
                    pBuscar()
                Else
                    lblMensajeCapcha.Text = Resources.Parametros.strMsjAlertaCapcha
                End If
            End If
        Else
            Me.lblMensajeCapcha.Text = Resources.Parametros.strMsjValidacion
        End If
    End Sub

End Class
