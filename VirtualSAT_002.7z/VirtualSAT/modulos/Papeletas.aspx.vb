Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.HomeSiteBLL
Imports SAT.Funciones.Validaciones
Imports SAT.SeguridadSAT.Encriptacion
Imports CaptchaDLL

Public Class modulos_Papeletas
    Inherits PageBase
    Private mstrPlaca As String
    Private intCaptcha As Integer = 4
    Private intTipUsr As Integer = 0

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'ValidarPagina()
        If Not IsPostBack Then
            Inicio()
            BuscadorInicial()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)            
        End If
    End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
                intTipUsr = 1
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing

        Me.lblFechaSistema.Text = GetFecha()
        Me.txtPlaca.Text = ""
        Me.txtPapeleta.Text = ""
        Me.divDataGrid.Style("height") = "2"
        'Me.btnBuscar.Attributes.Add("onclick", "return MenuAlertaProceso()")
        Me.txtPapeleta.Attributes.Add("onkeypress", "return desabilitaEnter(event)")
        Me.txtPlaca.Attributes.Add("onkeypress", "return desabilitaEnter(event)")
        MostrarOcultarDivPagos(False)
        Me.divDataGrid.Visible = False
        Me.btnPagar.Visible = False
        Me.fecConsulta.Visible = False
        Me.lblNota.Visible = False
        divResumen.Visible = False
        divMsg.Visible = False
        divMsgPapEst.Visible = False
        divMsgAdi.Visible = False
        btnRegDoc2.Visible = True  ''<<<<<<<<<<<<<<<<<<

        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha) 'Commet by test-kgc
        Console.WriteLine("fin de inicio")
    End Sub

    Private Sub BuscadorInicial()
        mstrPlaca = GetURL("pla")
        If mstrPlaca <> "" Then
            Me.txtPlaca.Text = mstrPlaca
        End If
    End Sub

    Private Sub PaginaMantenimiento()
        Me.lblCantidadRegistros.Text = "P�gina en mantenimiento, disculpe las molestias."
        MostrarOcultarDivPagos(False)
    End Sub

    Private Sub InicioDatagrid()
        Me.grdEstadoCuenta.DataSource = Nothing
        Me.grdEstadoCuenta.DataBind()
        Me.divDataGrid.Visible = True
        Me.lblCantidadRegistros.Text = ""
    End Sub

    Private Sub VerificarEstadoPagos()
        If GetEstadoPagosTransito() Then
            Me.grdEstadoCuenta.Columns(0).Visible = True
        Else
            Me.grdEstadoCuenta.Columns(0).Visible = False
        End If
    End Sub

    Private Sub MostrarOcultarDivPagos(ByVal vbolMostrar As Boolean)
        Me.divPagos.Visible = vbolMostrar
        If GetEstadoPagosTransito() = False Then
            Me.divPagos.Visible = False
        End If
    End Sub

    '''<summary>M�todo para mostrar las papeletas asociadas a una placa de veh�culo.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor></CreadoPor></item>
    '''<item><FecCrea></FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu>22/06/2010</FecActu></item>
    '''<item><Resp>David Miranda P.</Resp></item>
    '''<item><Mot>Filtrar los registros con deuda menor o igual a 0.</Mot></item></list></remarks>
    Private Sub BuscarxPlaca()
        'Dim oBLL As New ConsultasVarias
        Dim dsPapel As DataSet  ' Se paso como variable global

        Dim strPlaca As String
        Dim i, intCantidad As Integer
        Dim dblDeudaTotalSin As Double = 0
        Dim dblDeudaTotalCon As Double = 0
        Dim bolBeneficio As Boolean = GetEstadoBeneficio()
        Dim strPlacaAnt As String
        Dim strPlacaNue As String

        InicioDatagrid()
        VerificarEstadoPagos()

        Me.txtPapeleta.Text = ""
        Me.lblPlacaAso.Text = ""

        MostrarOcultarDivPagos(False)
        strPlaca = ValidaCadena(Me.txtPlaca.Text)

        '(1)--OJO CON LA UBICACION DE LA COLUMNA 7
        If GetEstadoBeneficio() Then
            Me.grdEstadoCuenta.Columns(8).Visible = True
        Else
            Me.grdEstadoCuenta.Columns(8).Visible = False
        End If
        '(1)--------------------------------------

        'Registro de busqueda
        RegistroDetalleBusqueda(GetConexionSoporteWEB, strPlaca, 0, Request.CurrentExecutionFilePath)
        '--------------------
        If strPlaca.Length > 5 Then
            'dsPapel = oBLL.BuscarDeudaPorInfraccion(GetConexionSiatTransito, strPlaca, GetFecha)    '<<<<<<<<<<<<<<<<<<<<<<<<<CONSULTA<<<<<<<<<<<<<<<
            dsPapel = pGetPapPorPlaca(strPlaca)

            If Not dsPapel Is Nothing Then
                If Not dsPapel.Tables(0).Columns.Contains("nTotal1") Then
                    dsPapel.Tables(0).Columns.Add(New DataColumn("nTotal1", System.Type.GetType("System.Double")))
                    dsPapel.AcceptChanges()
                End If
                ObtenerCapturas(dsPapel)
                dsPapel = ObtenerDocumentosDeuda(dsPapel)
                If dsPapel.Tables(0).Rows.Count > 0 Then
                    If Not dsPapel.Tables(0).Columns.Contains("nTotalBenef") Then
                        dsPapel.Tables(0).Columns.Add("nTotalBenef", GetType(Double))
                    End If

                    intCantidad = dsPapel.Tables(0).Rows.Count
                    For i = 0 To intCantidad - 1
                        dblDeudaTotalSin += CheckDbl(dsPapel.Tables(0).Rows(i)("nTotal"))
                    Next
                    If intCantidad > Me.grdEstadoCuenta.PageSize Then
                        Me.divDataGrid.Style("height") = CStr(12 * 26 + 40)
                    Else
                        Me.divDataGrid.Style("height") = CStr((intCantidad + 3) * 28 + 2)
                    End If

                    'Verificar Placa SUNARP
                    strPlacaAnt = CheckStr(dsPapel.Tables(0).Rows(0)("cPlacaAntigua"))
                    strPlacaNue = CheckStr(dsPapel.Tables(0).Rows(0)("cPlacaNueva"))
                    Me.lblPlacaAso.Text = MostrarPlacaAsociada(strPlaca, strPlacaAnt, strPlacaNue)
                    btnPagar.Visible = True
                    MostrarOcultarDivPagos(True)
                    Me.lblNota.Visible = True
                    divMsg.Visible = False
                    ' Me.lblCantidadRegistros.Text = "Se encontr� " + intCantidad.ToString + _
                    ' " documentos(s) pendientes de pago: <br>- Monto total a pagar : <b>S/. " + dblDeudaTotalSin.ToString("#,##0.00") + "</b>"
                Else
                    Me.divDataGrid.Style("height") = "50"
                    Me.lblMensajeVacio.Text = BuscarMensaje("estado_cuenta_papeletas_sin_datos").Replace("{0}", strPlaca)
                    divMsg.Visible = True
                    btnRegDoc2.Visible = False

                    txtBuscar.Visible = False
                    btnPagar.Visible = False
                    Me.lblNota.Visible = False
                End If
                Me.grdEstadoCuenta.DataSource = dsPapel.Tables(0)
                Me.grdEstadoCuenta.DataBind()

            End If
        Else
            Me.divDataGrid.Style("height") = "50"
            Me.lblMensajeVacio.Text = "La placa ingresada es incorrecta."
            divMsg.Visible = True
        End If


        If Not (dsPapel Is Nothing) Then dsPapel.Dispose()
        dsPapel = Nothing
        'oBLL = Nothing
    End Sub

    Private Function pGetPapPorPlaca(ByVal strPlaca As String) As DataSet

        Dim dsData As New DataSet
        Dim oBLL As New ConsultasVarias

        dsData = oBLL.BuscarDeudaPorInfraccion(GetConexionSiatTransito, strPlaca, GetFecha)    '<<<<<<<<<<<<<<<<<<<<<<<<<CONSULTA<<<<<<<<<<<<<<<
        Return dsData

        oBLL = Nothing
    End Function

    '''<summary>M�todo para obtener las papeletas pendientes de pago.</summary>
    ''' <param name="vds">Dataset con los datos de las papeletas.</param>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>David Miranda</CreadoPor></item>
    '''<item><FecCrea>23/06/2010</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu>15/11/2012</FecActu></item>
    '''<item><Resp>David Miranda Palomino</Resp></item>
    '''<item><Mot>Implementaci�n de la Ord. 1634</Mot></item></list></remarks>
    Private Function ObtenerDocumentosDeuda(ByVal vds As DataSet) As DataSet
        Dim dt As New DataTable
        Dim dv As New DataView
        Dim dr As DataRow
        Dim strPapeleta As String = ""
        Dim intTotPla As Integer
        Dim dblTotal As Double = 0.0
        Dim dblBenef As Double = 0.0
        Try
            If Not vds Is Nothing Then
                ' Aplicaci�n de Beneficio 2012
                intTotPla = vds.Tables(0).Rows.Count - 1
                For intRow As Integer = 0 To intTotPla
                    dblTotal = 0.0
                    dblBenef = 0.0
                    With vds.Tables(0).Rows(intRow)
                        dblTotal = SAT.Base.Lib.Datos.CheckDbl(.Item("nTotal1"))
                        dblBenef += SAT.Base.Lib.Datos.CheckDbl(.Item("nCuotaBen"))
                        dblBenef += SAT.Base.Lib.Datos.CheckDbl(.Item("nDerEmiBen"))
                        dblBenef += SAT.Base.Lib.Datos.CheckDbl(.Item("nReinciBen"))
                        dblBenef += SAT.Base.Lib.Datos.CheckDbl(.Item("nReajusBen"))
                        dblBenef += SAT.Base.Lib.Datos.CheckDbl(.Item("nIntereBen"))
                        dblBenef += SAT.Base.Lib.Datos.CheckDbl(.Item("nMoraBen"))
                        dblBenef += SAT.Base.Lib.Datos.CheckDbl(.Item("nCostasBen"))
                        dblBenef += SAT.Base.Lib.Datos.CheckDbl(.Item("nGastosBen"))
                        dblTotal = dblTotal - dblBenef
                        .Item("nTotal1") = dblTotal
                    End With
                Next
                vds.AcceptChanges()
                '
                dv = vds.Tables(0).DefaultView
                dv.RowFilter = "nTotal1 > 0"
                dv.Sort = "cPapele Asc"
                vds.Tables.Clear()
                vds.Tables.Add(dv.ToTable)
                vds.AcceptChanges()
                dt = vds.Tables(0).Clone
                If vds.Tables(0).Rows.Count > 0 Then
                    strPapeleta = ""
                    For Each dRow As DataRow In vds.Tables(0).Rows
                        If Not strPapeleta = dRow.Item("cPapele").ToString.Trim Then
                            dr = dt.NewRow()
                            dr.ItemArray = dRow.ItemArray
                            dt.Rows.Add(dr)
                            strPapeleta = dRow.Item("cPapele").ToString.Trim
                        End If
                    Next
                    dt.AcceptChanges()
                    dv = dt.DefaultView
                    dv.Sort = "sdFecInf Desc"
                    vds.Tables.Clear()
                    vds.Tables.Add(dv.ToTable)
                    vds.AcceptChanges()
                End If
            End If
        Catch ex As Exception
            Throw
        Finally
            If Not (dt Is Nothing) Then dt.Dispose()
            If Not (dv Is Nothing) Then dv.Dispose()
            dt = Nothing
            dv = Nothing
            dr = Nothing
        End Try
        Return vds
    End Function

    Private Function MostrarPlacaAsociada(ByVal vstrPlacaBus As String, _
                                          ByVal vstrPlacaAnt As String, _
                                          ByVal vstrPlacaNue As String) As String
        Dim strMensaje As String = ""
        If vstrPlacaAnt = "" And vstrPlacaNue = "" Then
            strMensaje = ""
        Else
            If vstrPlacaAnt <> "" And vstrPlacaNue <> "" Then
                strMensaje = "<span style='font-size:9px;'><b>1/</b><span> " & vstrPlacaNue & " (antes " & vstrPlacaAnt & ")"
            Else
                strMensaje = ""
            End If
        End If
        Return strMensaje
    End Function
    Private Sub pSetColorGridPap(ByRef dsPapel As DataSet, ByVal strPapele As String)

        For Each item As DataRow In dsPapel.Tables(0).Rows
            If item("cPapele").ToString().Contains(strPapele) Then

            End If
        Next

    End Sub

    Private Sub BuscarPapeleta()
        Dim oBLL As New ConsultasVarias
        Dim dsPapel As DataSet
        Dim dsPapel2 As DataSet
        Dim strPapeleta As String
        Dim strEstado As String
        Dim strPlaca As String
        Dim intPapEst As Int16

        InicioDatagrid()
        Me.txtPlaca.Text = ""
        strPapeleta = ValidaCadena(Me.txtPapeleta.Text)
        'Registro de busqueda-----------
        RegistroDetalleBusqueda(GetConexionSoporteWEB, strPapeleta, 0, Request.CurrentExecutionFilePath)
        '-------------------------------
        If strPapeleta.Length > 5 Then
            dsPapel = oBLL.BuscarPapeleta(GetConexionSiatTransito, strPapeleta)
            If Not dsPapel Is Nothing Then
                If dsPapel.Tables(0).Rows.Count > 0 Then
                    strPapeleta = dsPapel.Tables(0).Rows(0).Item("cPapele").ToString().Trim()
                    strEstado = dsPapel.Tables(0).Rows(0).Item("vEstado").ToString().Trim()
                    strPlaca = dsPapel.Tables(0).Rows(0).Item("cPlaca").ToString().Trim()
                    intPapEst = Convert.ToInt16(dsPapel.Tables(0).Rows(0).Item("siTipEdo"))

                    If intPapEst = 1 Then
                        'divDataGrid.Visible = True
                        grdEstadoCuenta.Visible = True
                        txtPlaca.Text = strPlaca

                        BuscarxPlaca()  ''<<<<<<<<<< 
                        txtPapeleta.Text = strPapeleta
                        ClientScript.RegisterStartupScript(Me.GetType, "script", "filter2();", True)  '' << SCRIPT JS
                        txtBuscar.Visible = True
                        'pMostrarSinPlaca(dsPapel)   '<<<<<<<
                        divMsg.Visible = False
                        divMsgPapEst.Visible = False
                        btnPagar.Visible = True
                    Else
                        'divDataGrid.Visible = False
                        grdEstadoCuenta.Visible = False
                        dsPapel2 = pGetPapPorPlaca(strPlaca)

                        Dim lpend As Boolean = False
                        For Each item As DataRow In dsPapel2.Tables(0).Rows

                            If item("Estado").ToString.Contains("Pendiente") Then
                                lpend = True
                                Exit For
                            End If

                        Next
                        If intPapEst = 2 Then

                            lblMsgPapEst.Text = BuscarMensaje("estado_cuenta_papeletas_cancelado").Replace("{0}", strPapeleta)
                            lblPlacaRes.Text = dsPapel.Tables(0).Rows(0).Item("cPlaca").ToString()
                            lblNumDocSRes.Text = dsPapel.Tables(0).Rows(0).Item("cPapele").ToString()
                            lblCodigoInfRes.Text = dsPapel.Tables(0).Rows(0).Item("cCodFal").ToString()
                            lblImporteRes.Text = dsPapel.Tables(0).Rows(0).Item("nCuota").ToString()
                            lblFecPagRes.Text = dsPapel.Tables(0).Rows(0).Item("sdFecEmi").ToString()

                            divResumen.Visible = True

                        ElseIf intPapEst = 4
                            lblMsgPapEst.Text = BuscarMensaje("estado_cuenta_papeletas_Anulado").Replace("{0}", strPapeleta)
                            divResumen.Visible = False
                        End If

                        If lpend Then
                            lblMsgPapAdic.Text = BuscarMensaje("estado_cuenta_papeletas_pendientes")
                            'lblMsgPapAdic.Visible = True
                            divMsgAdi.Visible = True
                            btnVerPap.Visible = True
                            mstrPlaca = strPlaca

                            Me.txtPlaca.Text = strPlaca
                        Else
                            btnVerPap.Visible = False
                            divMsgAdi.Visible = False
                            lblMsgPapAdic.Visible = False
                            btnVerPap.Visible = False
                        End If

                        divMsgPapEst.Visible = True
                        lblMsgPapEst.Visible = True
                        divMsg.Visible = False
                        btnPagar.Visible = False

                    End If

                Else

                    Me.lblMensajeVacio.Text = BuscarMensaje("estado_cuenta_papeletas_noexiste").Replace("{0}", strPapeleta)
                    divMsg.Visible = True
                    divMsgPapEst.Visible = False
                    btnPagar.Visible = False
                    btnRegDoc2.Visible = False

                End If
            End If

        Else
            Me.divDataGrid.Style("height") = "50"
            Me.lblMensajeVacio.Text = "N�mero de papeleta incorrecto."
            divMsg.Visible = True
        End If
        dsPapel = Nothing
        oBLL = Nothing

    End Sub

    Protected Sub grdEstadoCuenta_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdEstadoCuenta.PageIndexChanging
        grdEstadoCuenta.PageIndex = e.NewPageIndex
        BuscarxPlaca()
    End Sub

    Protected Sub grdEstadoCuenta_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdEstadoCuenta.RowDataBound
        Dim strPapel As String = ""
        Dim strPlacaPap As String = ""
        Dim strPlacaAnt As String = ""
        Dim strPlacaNue As String = ""

        If e.Row.RowType = DataControlRowType.DataRow Then
            ProcesarFilaDataGrid(e)
            strPapel = CType(e.Row.FindControl("lblDocumento"), Label).Text.Trim
            strPapel = Encrypt(strPapel, Left(Date.Today.ToShortDateString, 8))
            strPapel = System.Web.HttpUtility.UrlEncodeUnicode(strPapel)
            'CType(e.Row.FindControl("lnkImagen"), HyperLink).NavigateUrl = "~/../imagenespapeleta/ImagenPapeleta.aspx?papel=" + strPapel ''Coment-by-test
            CType(e.Row.FindControl("lnkImagen"), HyperLink).NavigateUrl = "~/imagenespapeleta/ImagenPapeleta.aspx?papel=" + strPapel
            CType(e.Row.FindControl("lnkImagen"), HyperLink).Target = "_blank"

            strPlacaPap = CheckStr(DataBinder.Eval(e.Row.DataItem, "cPlacaPap"))
            strPlacaAnt = CheckStr(DataBinder.Eval(e.Row.DataItem, "cPlacaAntigua"))
            strPlacaNue = CheckStr(DataBinder.Eval(e.Row.DataItem, "cPlacaNueva"))
            Dim lblSunarp As Label = CType(e.Row.FindControl("lblSunarp"), Label)
            lblSunarp.Text = "1/"

            If Not lblSunarp Is Nothing Then
                If strPlacaPap = strPlacaAnt Or strPlacaAnt = "" Or strPlacaNue = "" Then
                    lblSunarp.Visible = False
                End If
            End If

            strPapel = CType(e.Row.FindControl("lblDocumento"), Label).Text.Trim
            If strPapel.StartsWith("E") Then
                strPapel = Encrypt(strPapel, Date.Today.ToShortDateString)
                strPapel = System.Web.HttpUtility.UrlEncodeUnicode(strPapel)
                CType(e.Row.FindControl("lnkDocumento"), HyperLink).NavigateUrl = "https://www.sat.gob.pe/imagenvelox/frmImagenEvidencia.aspx?pap=" + strPapel
                CType(e.Row.FindControl("lnkDocumento"), HyperLink).Target = "_blank"
            Else
                CType(e.Row.FindControl("lnkDocumento"), HyperLink).Visible = False
            End If

            lblSunarp = Nothing

            If CType(e.Row.FindControl("lblDescuento"), Label).Text <> "0.00" Then
                CType(e.Row.FindControl("lblDescuento"), Label).Attributes.Add("style", "background:#8DDB8D")
            End If

        End If
    End Sub

    Protected Sub btnPagar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnPagar.Click
        Dim oBLL As New FuncionesCarrito
        oBLL.ProcesarGridCarritoTransito(grdEstadoCuenta, "Papeletas")
        oBLL = Nothing
        ucDatosCarrito1.Refrescar()
    End Sub

    Protected Sub btnRegDoc_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnRegDoc.Click

        'Response.Redirect(BuscarMensaje("pagina_registro_papeleta") + "?" + SetURL("mysession", MySessionID))

        If intTipUsr = 0 Then
            Response.Redirect(BuscarMensaje("pagina_login_dj") + "&pap=" + txtPapeleta.Text.Trim)
        ElseIf intTipUsr = 1
            Response.Redirect(BuscarMensaje("pagina_registro_papeleta") + "?" + SetURL("mysession", MySessionID))
        End If



    End Sub

    Protected Sub ImageButton1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Dim oCar As New FuncionesCarrito
        oCar.ProcesarGridCarritoTransito(grdEstadoCuenta, "Papeletas")
        oCar = Nothing
    End Sub

    Private Sub pMostrarSinPlaca(ByVal vdsPapeleta As DataSet)
        Dim intcantidad As Integer = 0
        Dim i As Integer
        Dim dblDeudaTotalSin As Double = 0

        InicioDatagrid()
        VerificarEstadoPagos()

        Me.lblPlacaAso.Text = ""
        MostrarOcultarDivPagos(False)

        '(1)--OJO CON LA UBICACION DE LA COLUMNA 7
        If GetEstadoBeneficio() Then
            Me.grdEstadoCuenta.Columns(8).Visible = True
        Else
            Me.grdEstadoCuenta.Columns(8).Visible = False
        End If
        '(1)--------------------------------------

        vdsPapeleta.Tables(0).Columns.Add(New DataColumn("Concepto", System.Type.GetType("System.String")))
        vdsPapeleta.Tables(0).Columns.Add(New DataColumn("nTotalBenef", System.Type.GetType("System.Double")))
        vdsPapeleta.Tables(0).Columns.Add(New DataColumn("nImporte", System.Type.GetType("System.Double")))
        vdsPapeleta.Tables(0).Columns.Add(New DataColumn("nInteres", System.Type.GetType("System.Double")))
        vdsPapeleta.Tables(0).Columns.Add(New DataColumn("cPlacaAntigua", System.Type.GetType("System.String")))
        vdsPapeleta.Tables(0).Columns.Add(New DataColumn("cPlacaNueva", System.Type.GetType("System.String")))
        vdsPapeleta.Tables(0).Columns.Add(New DataColumn("cDesAbr", System.Type.GetType("System.String")))

        vdsPapeleta.Tables(0).Columns("cPlaca").ColumnName = "cPlacaPap"
        vdsPapeleta.Tables(0).Columns("nCuota").ColumnName = "Cuota"
        vdsPapeleta.Tables(0).Columns("nSaldo").ColumnName = "nTotal"
        vdsPapeleta.Tables(0).Columns("vEstado").ColumnName = "Estado"
        vdsPapeleta.Tables(0).Columns("nGastos").ColumnName = "nGasto"
        vdsPapeleta.Tables(0).Columns("nTasDes").ColumnName = "PorcentajeDesc"

        vdsPapeleta.AcceptChanges()

        If vdsPapeleta.Tables(0).Rows.Count > 0 Then

            intcantidad = vdsPapeleta.Tables(0).Rows.Count
            For i = 0 To intcantidad - 1
                vdsPapeleta.Tables(0).Rows(i)("Concepto") = "Papeleta"
                vdsPapeleta.Tables(0).Rows(i)("nImporte") = vdsPapeleta.Tables(0).Rows(i)("Cuota")
                vdsPapeleta.Tables(0).Rows(i)("nTotal") = CheckDbl(vdsPapeleta.Tables(0).Rows(i)("nTotal")) - CheckDbl(vdsPapeleta.Tables(0).Rows(i)("nDescuento"))
                dblDeudaTotalSin += CheckDbl(vdsPapeleta.Tables(0).Rows(i)("nTotal"))
            Next
            If intcantidad > Me.grdEstadoCuenta.PageSize Then
                Me.divDataGrid.Style("height") = CStr(12 * 26 + 2)
            Else
                Me.divDataGrid.Style("height") = CStr((intcantidad + 2) * 26)
            End If

            'Me.lblCantidadRegistros.Text = "Se encontr� " + intcantidad.ToString + _
            '" documentos(s) pendientes de pago: <br>- Monto total a pagar : <b>S/. " + dblDeudaTotalSin.ToString("#,##0.00") + "</b>"

            If dblDeudaTotalSin > 0 Then MostrarOcultarDivPagos(True)

        Else
            Me.divDataGrid.Style("height") = "50"
            Me.lblMensajeVacio.Text = BuscarMensaje("estado_cuenta_papeletas_sin_datos")
        End If

        vdsPapeleta.AcceptChanges()

        Me.grdEstadoCuenta.DataSource = vdsPapeleta.Tables(0)
        Me.grdEstadoCuenta.DataBind()

        lblMensajeSunarp.Visible = False

        vdsPapeleta = Nothing

    End Sub

    '''<summary>M�todo para obtener las papeletas con captura.</summary>
    ''' <param name="vds">Dataset con los datos de las papeletas.</param>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Duglas Q.</CreadoPor></item>
    '''<item><FecCrea>07/05/2013</FecCrea></item></list></remarks>
    Private Sub ObtenerCapturas(ByVal vds As DataSet)
        Dim dv As New DataView
        Try
            If Not vds Is Nothing Then
                dv = vds.Tables(0).DefaultView
                dv.RowFilter = "iCantidadCaptura > 0"
                If dv.Count > 0 Then
                    Me.lblCantidadRegistros.Text = "IMPORTANTE: la placa ingresada tiene orden de captura, vea los detalles en la opci�n 'Captura de veh�culos' de la parte izquierda."
                End If
            End If
        Catch ex As Exception
            Throw
        Finally
            dv = Nothing
        End Try
    End Sub

    Protected Sub ibtnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    Protected Sub CaptchaContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CaptchaContinue.Click
        If Not String.IsNullOrEmpty(lblMensajePapeleta.Text.Trim()) Then
            Return
        End If
        GestionarConsulta()
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)

    End Sub

    '''<summary>M�todo para validar el c�digo captcha.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Function fbln_ValidarCaptha() As Boolean
        Dim blnRespuesta As Boolean = False
        Me.divDataGrid.Visible = True
        Me.btnPagar.Visible = True
        Me.fecConsulta.Visible = True
        Me.filter_div.Visible = False
        blnRespuesta = True

        Return True
    End Function
    '' /////////////////////////////////////////// BUSQUEDA ///////////////////////////////////////////////////////////////////////////////////

    '''<summary>M�todo para ejecutar las consultas en base al tipo de consulta.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Sub GestionarConsulta()
        BtnExcesoPap.Visible = False

        If (Me.hidTipConsulta.Value = "busqPlaca") Then
            Me.divBusPlaca.Visible = True
            Me.busqPapeleta.Visible = False
            Me.divCaptchaPapeletas.Visible = True  'DIV
            divResumen.Visible = False
            If fbln_ValidarCaptha() Then
                Me.lblMsjCodSeg.Text = Nothing
                BuscarxPlaca()
            Else
                Me.lblMsjCodSeg.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
            Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
        ElseIf (Me.hidTipConsulta.Value = "busqPapeleta") Then

            txtBuscar.Visible = False
            Me.divBusPlaca.Visible = False
            Me.busqPapeleta.Visible = True
            Me.divCaptchaPapeletas.Visible = True
            If fbln_ValidarCaptha() Then
                Me.lblMsjPapeletaCodSeg.Text = Nothing
                BuscarPapeleta()
            Else
                Me.lblMsjPapeletaCodSeg.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
            Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
        Else
            Me.divBusPlaca.Visible = False
            Me.busqPapeleta.Visible = False
            Me.divCaptchaPapeletas.Visible = False
        End If
    End Sub

    '' /////////////////////////////////////////// Fin-BUSQUEDA ///////////////////////////////////////////////////////////////////////////////////


    Private Function ValidarNumDocSancion() As String

        Dim script As String = "window.onload = function() { ValidarNumDocS(); };"
        ClientScript.RegisterStartupScript(Me.GetType(), "ValidarNumDocS", script, True)


        Dim shCodMun As Int16 = 1
        Dim strNumDocS As String = txtPapeleta.Text.Trim()

        Dim dtTabla As New DataTable
        'dtTabla = fdta_Papeleta_BuscarEstado(shCodMun, strNumDocS)
        'dtTabla = FuncionesWeb.fdta_Papeleta_BuscarEstado(shCodMun, strNumDocS)
        dtTabla = Nothing
        If (dtTabla Is Nothing OrElse dtTabla.Rows.Count = 0) Then
            Return String.Empty
        End If

        'lblMensaje.Text = dtTabla.Rows(0)(3).ToString

        Return dtTabla.Rows(0).Item("EstadoDoc").ToString()
    End Function

    ''' <summary>
    ''' STORES PROCED.
    ''' </summary>
    ''' <returns></returns>
    ''' 

    Protected Sub btnVerPap_Click(sender As Object, e As EventArgs) Handles btnVerPap.Click

        hidTipConsulta.Value = "busqPlaca"

        If Me.txtPlaca.Text.Trim <> "" Then
            BuscarxPlaca()  '<<<<<<<
            divResumen.Visible = False
            btnRegDoc.Visible = False
            txtBuscar.Visible = True
            btnVerPap.Visible = False
            divMsgAdi.Visible = False
            grdEstadoCuenta.visible = True
        End If

    End Sub
    Protected Sub btnRegDoc2_Click(sender As Object, e As EventArgs) Handles btnRegDoc2.Click
        btnRegDoc_Click(sender, e)
    End Sub
    Protected Sub btnExcesoPap_Click(sender As Object, e As EventArgs) Handles btnExcesoPap.Click
        'Response.Redirect(BuscarMensaje("pagina_exceso_papeleta") + "?" + SetURL("mysession", MySessionID))
        'Response.Redirect(BuscarMensaje("pagina_exceso_papeleta"))
        'Response.Redirect(BuscarMensaje("pagina_exceso_papeleta"))

    End Sub
End Class
