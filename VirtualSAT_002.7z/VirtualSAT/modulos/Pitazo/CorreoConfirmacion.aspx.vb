﻿Option Explicit On
Option Strict On
Imports FuncionesWeb
Imports System.Data
Imports SAT.HomeSiteBLL.ConsultasWeb
Imports SAT.Funciones.Validaciones
Partial Class modulos_pitazo_CorreoConfirmacion
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
            Dim dsUsuario As DataSet
            Dim strMensaje As String = ""
            Dim strMensaje2 As String = ""
            Dim intCodUsuario As Integer = 0
            Dim strApePat, strApeMat, strNombre, strEmail, strCodigo, strCelular, strCodUsuario As String
            Dim strServer As String = ""
            Dim strRuta As String = ""
            Dim strRutaReconfirmacion As String = ""
            Dim strCodigoEncriptado As String = ""


            strCodigo = GetURL("codigo")
            strCodigoEncriptado = SetURL("codigo", strCodigo)
            intCodUsuario = Convert.ToInt32(strCodigo)

            If intCodUsuario > 0 Then
                dsUsuario = oBLL.BuscarUsuarioWEBxCodigo(GetConexionSoporteWEB, intCodUsuario)
                If Not dsUsuario Is Nothing Then
                    If dsUsuario.Tables(0).Rows.Count > 0 Then
                        intCodUsuario = CheckInt(dsUsuario.Tables(0).Rows(0)("NCODUSU"))
                        strCodUsuario = Convert.ToString(intCodUsuario)
                        strApePat = CheckStr(dsUsuario.Tables(0).Rows(0)("VAPEPAT"))
                        strApeMat = CheckStr(dsUsuario.Tables(0).Rows(0)("VAPEMAT"))
                        strNombre = CheckStr(dsUsuario.Tables(0).Rows(0)("VNOMBRE"))
                        strEmail = CheckStr(dsUsuario.Tables(0).Rows(0)("VEMAIL"))
                        strCelular = CheckStr(dsUsuario.Tables(0).Rows(0)("VCELULA"))
                        strRutaReconfirmacion = "CorreoReconfirmacion.aspx?" + strCodigoEncriptado

                        Me.hdnHref.Value = strRutaReconfirmacion

                        Me.lblEmail.Text = Trim(strEmail)

                        'Enviar constancia de registro
                        strMensaje = ""
                        strMensaje += "Gracias por registrarse como usuario del servicio Pit@zo preventivo e informativo. " & Chr(13) & Chr(13)

                        If Request.ServerVariables("SERVER_NAME") = "webiisprod01" Then
                            strServer = "https://www.sat.gob.pe/VirtualSat/modulos/Pitazo/FinRegistroCorreo.aspx?" + strCodigoEncriptado
                        ElseIf Request.ServerVariables("SERVER_NAME") = "webiispre01" Then
                            strServer = "http://webiispre01/VirtualSat/modulos/Pitazo/FinRegistroCorreo.aspx?" + strCodigoEncriptado
                        ElseIf (Request.ServerVariables("SERVER_NAME") = "webiis_des01" Or Request.ServerVariables("SERVER_NAME") = "172.29.55.188") Then
                            strServer = "http://webiis_des01/VirtualSat/modulos/Pitazo/FinRegistroCorreo.aspx?" + strCodigoEncriptado
                        Else
                            strServer = "https://www.sat.gob.pe/VirtualSat/modulos/Pitazo/FinRegistroCorreo.aspx?" + strCodigoEncriptado
                        End If

                        strMensaje += "A fin de concluir con el proceso de registro, visite el siguiente enlace " & Chr(13) & Chr(13)
                        strMensaje += "(Si tienes problemas con el codigo de seguridad, por favor copia directamente el link en tu navegador y recarga la pagina) : " & Chr(13)
                        'strMensaje += strServer
                        'strMensaje += "<a href=" & Chr(34) & strServer & Chr(34) + ">" & strServer & "</a>"
                        strMensaje += Chr(32) & strServer & Chr(32) '& Chr(13)

                        strMensaje += "  Esta es la informacion de la cuenta:" & Chr(13) & Chr(13)
                        strMensaje += "Nombre  : " & Trim(UCase(strNombre)) & " " & Trim(UCase(strApePat)) & " " & Trim(UCase(strApeMat)) & " " & Chr(13) & Chr(13)
                        strMensaje += "Usuario : " & strEmail & Chr(13) & Chr(13)
                        strMensaje += "Atentamente," & Chr(13) & Chr(13)
                        strMensaje += "Servicio de Administracion Tributaria" & Chr(13) & Chr(13)

                        strMensaje += "PD: Las tildes y enies se han omitido para evitar problemas de compatibilidad entre los software de correo electronico" & Chr(13) & Chr(13)

                        If strEmail <> "" Then
                            Using oBLLMail As New SAT.SIAT.COM.BLL.Libreria.NX.Correo
                                oBLLMail.EnvioEmail("REGISTRO - SAT <satvirtual@sat.gob.pe>", strEmail, "SAT Confirmacion de registro", strMensaje)
                            End Using
                        End If
                        If strCelular <> "" Then
                            Me.btnContinuar.Visible = True
                            Me.hdncodigo.Value = strCodUsuario
                        Else
                            Me.btnContinuar.Visible = False
                        End If
                    End If
                End If
            End If
        End If
    End Sub

End Class
