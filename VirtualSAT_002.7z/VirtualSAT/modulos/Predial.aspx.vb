Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb

Partial Class Predial
    Inherits PageBase

    Private mintCodigoUsuario As Integer

    Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'mstrCodigoUsuario = FuncionesWeb.GetCodigoUsuario
        If Not IsPostBack Then
            Inicio()
        End If
    End Sub

    Private Sub Inicio()
        Dim oBLL As New ConsultasVarias
        Dim ds As DataSet
        ds = oBLL.BuscarPrediosxPropietario(GetConexionSiatTributos, mintCodigoUsuario)
        If Not ds Is Nothing Then
            Me.grdPredios.DataSource = ds.Tables(0)
            Me.grdPredios.DataBind()
        End If
        oBLL = Nothing
    End Sub

End Class
