﻿
Partial Class modulos_Redirect
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim strIP As String = Request.ServerVariables("REMOTE_ADDR")

        If strIP.Contains("172.29.") Or strIP.Contains("192.168.") Then
            Response.Redirect("http://" + Resources.Parametros.strURLPreliquiInt)
        Else
            Response.Redirect("http://" + Resources.Parametros.strURLPreliquiExt)
        End If

    End Sub
End Class
