﻿Imports System.Data
Imports System.Data.SqlClient
Imports Microsoft.VisualBasic

Public Class Conexion

    'Public Shared Sub run_sp(ByVal sp_name As Int16, ByVal sp_para As String)
    '    Dim dtTabla As New DataTable

    '    Dim cnCnx As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings("BDSIAT001").ConnectionString)

    '    cnCnx.Open()

    '    Dim cmd As SqlCommand = New SqlCommand("spRe_Papeleta_BuscarEstado", cnCnx)
    '    cmd.CommandType = CommandType.StoredProcedure
    '    cmd.Parameters.AddWithValue("@psiCodMun", pshsiCodMun)
    '    cmd.Parameters.AddWithValue("@pcPapele", pstrcPapele)

    '    Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
    '    da.Fill(dtTabla)

    '    Return dtTabla
    'End Sub

End Class
