Option Explicit On
Option Strict On

Imports SAT.SeguridadSAT.Encriptacion
Imports SAT.Funciones.Validaciones
Imports System.Data
Imports FuncionesWeb
Imports SAT.HomeSiteBLL

Public Class FuncionesCarrito

    Public Sub ProcesarGridCarritoTributos(ByVal vdg As GridView, _
                                           ByVal vstrConcepto As String)
        Dim i As Integer = 0
        Dim dtCarritoTemp As DataTable
        Dim bolBeneficio As Boolean = False
        Dim intAnio, intConcepto As Integer
        Dim dblMonto As Double = 0
        Dim strDocumento As String = ""
        Dim intPeriodo As Integer = 0

        dtCarritoTemp = GetEstructuraTablaCarrito()
        For i = 0 To vdg.Rows.Count - 1
            intAnio = Integer.Parse(CType(vdg.Rows.Item(i).FindControl("lblAnio"), Label).Text)
            intConcepto = Integer.Parse(CType(vdg.Rows.Item(i).FindControl("lblCodCre"), Label).Text)
            dblMonto = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblDeuda"), Label).Text)
            strDocumento = CType(vdg.Rows.Item(i).FindControl("lblDocumento"), Label).Text.Trim
            If CType(vdg.Rows.Item(i).FindControl("chkSeleccion"), CheckBox).Checked _
                        And dblMonto > 0 _
                        And strDocumento <> "" Then
                Dim dr As DataRow
                dr = dtCarritoTemp.NewRow
                dr("id") = i
                dr("concepto") = CType(vdg.Rows.Item(i).FindControl("lblDesTributo"), Label).Text
                dr("referencia") = CType(vdg.Rows.Item(i).FindControl("lblAdministrado"), Label).Text.Replace("�", "N")
                dr("documento") = CType(vdg.Rows.Item(i).FindControl("lblDocumento"), Label).Text.Replace(".", "")
                intPeriodo = Integer.Parse(CType(vdg.Rows.Item(i).FindControl("lblPeriodo"), Label).Text)
                If intPeriodo = 0 Then
                    dr("monto") = 0
                Else
                    dr("monto") = dblMonto
                End If
                dr("ncuota") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblCuota"), Label).Text)
                dr("emision") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblEmision"), Label).Text)
                dr("reajuste") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblReajuste"), Label).Text)
                dr("mora") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblMora"), Label).Text)
                dr("importe") = 0
                dr("reinci") = 0
                dr("gastos") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblGastos"), Label).Text)
                dr("costas") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblCostas"), Label).Text)
                dr("descuento") = 0
                dr("sicodcre") = Integer.Parse(CType(vdg.Rows.Item(i).FindControl("lblCodCre"), Label).Text)
                dr("anio") = intAnio
                dr("periodo") = intPeriodo
                dr("datosimp") = CType(vdg.Rows.Item(i).FindControl("lblAdministrado"), Label).Text
                dr("icodper") = CheckInt(CType(vdg.Rows.Item(i).FindControl("lblCodigo"), Label).Text)
                dr("sdFecVen") = CheckStr(CType(vdg.Rows.Item(i).FindControl("lblFecVen"), Label).Text)
                If IsNumeric(CType(vdg.Rows.Item(i).FindControl("lblCodPre"), Label).Text) Then
                    dr("iCodPre") = CheckStr(CType(vdg.Rows.Item(i).FindControl("lblCodPre"), Label).Text)
                End If
                dr("num_pagina") = vdg.PageIndex
                If intPeriodo > 0 Then
                    dtCarritoTemp.Rows.Add(dr)
                End If
            End If
        Next

        CargarPagosCarrito(dtCarritoTemp, vstrConcepto, vdg.PageIndex)

    End Sub

    Public Sub ProcesarGridCarritoTransito(ByVal vdg As GridView, ByVal vstrConcepto As String)
        Dim i As Integer = 0
        Dim dtCarritoTemp As DataTable
        Dim bolBeneficio As Boolean = False
        Dim dblMonto As Double = 0

        dtCarritoTemp = GetEstructuraTablaCarrito()
        For i = 0 To vdg.Rows.Count - 1
            bolBeneficio = GetEstadoBeneficio()
            If Not bolBeneficio Then
                dblMonto = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblDeuda"), Label).Text)
            Else
                dblMonto = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblBeneficio"), Label).Text)
            End If
            If CType(vdg.Rows.Item(i).FindControl("chkSeleccion"), CheckBox).Checked And dblMonto > 0 Then
                Dim dr As DataRow
                dr = dtCarritoTemp.NewRow
                dr("id") = i
                dr("concepto") = vstrConcepto
                dr("referencia") = CType(vdg.Rows.Item(i).FindControl("lblPlaca"), Label).Text + " " + GetNombreReglamento(Integer.Parse(CType(vdg.Rows.Item(i).FindControl("lblCodCre"), Label).Text)) + " " + CType(vdg.Rows.Item(i).FindControl("lblFalta"), Label).Text + " " + CType(vdg.Rows.Item(i).FindControl("lblFecha"), Label).Text
                dr("documento") = CType(vdg.Rows.Item(i).FindControl("lblDocumento"), Label).Text
                dr("monto") = dblMonto
                dr("ncuota") = 0
                dr("emision") = 0
                dr("reajuste") = 0
                If IsNumeric(vdg.Rows.Item(i).FindControl("lblMora")) Then
                    dr("mora") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblMora"), Label).Text)
                Else
                    dr("mora") = 0
                End If
                dr("importe") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblImporte"), Label).Text)
                'dr("reinci") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblReinci"), Label).Text)
                dr("reinci") = 0
                dr("gastos") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblGastos"), Label).Text)
                dr("costas") = 0
                dr("descuento") = Double.Parse(CType(vdg.Rows.Item(i).FindControl("lblDescuento"), Label).Text)
                dr("sicodcre") = Integer.Parse(CType(vdg.Rows.Item(i).FindControl("lblCodCre"), Label).Text)
                dr("anio") = CDate(CType(vdg.Rows.Item(i).FindControl("lblFecha"), Label).Text).Year
                dr("periodo") = CDate(CType(vdg.Rows.Item(i).FindControl("lblFecha"), Label).Text).Month
                dr("datosimp") = CType(vdg.Rows.Item(i).FindControl("lblPlaca"), Label).Text + " " + CType(vdg.Rows.Item(i).FindControl("lblFalta"), Label).Text + " " + CType(vdg.Rows.Item(i).FindControl("lblFecha"), Label).Text
                dr("icodper") = 0
                dr("server") = "P"

                dtCarritoTemp.Rows.Add(dr)
            End If
        Next
        CargarPagosCarritoTransito(dtCarritoTemp, vstrConcepto)
    End Sub

    Public Shared Function GetEstructuraTablaCarrito() As DataTable
        Dim dt As New DataTable("dt_carrito_pagos")
        dt.Columns.Add(New DataColumn("id", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("concepto", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("referencia", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("documento", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("monto", Type.GetType("System.Double")))

        dt.Columns.Add(New DataColumn("sicodcre", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("anio", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("periodo", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("datosimp", Type.GetType("System.String")))

        dt.Columns.Add(New DataColumn("ncuota", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("emision", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("reajuste", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("mora", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("importe", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("reinci", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("gastos", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("costas", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("descuento", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("icodper", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("administrado", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("sdFecVen", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("pagado", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("server", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("iCodPre", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("cuotaunica", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("montosiat", Type.GetType("System.Double")))
        dt.Columns.Add(New DataColumn("num_pagina", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("derecho", Type.GetType("System.String")))

        dt.PrimaryKey = New DataColumn() {dt.Columns("documento")}
        Return dt
    End Function

    Public Shared Function GetCarrito() As DataSet
        Dim strSession As String = GetSessionID().ToString + "_Pagos"
        Dim dsCarrito As New DataSet
        Dim strFile As String = GetRutaFisica("temp/") + strSession + ".xml"
        If IO.File.Exists(strFile) Then
            dsCarrito.ReadXml(strFile)
        End If
        Return dsCarrito
    End Function

    Public Shared Sub SalvarCarrito(ByVal vds As DataSet)
        'Dim strSession As String = GetSessionID().ToString + "_" + GetConceptoReca.ToString()
        Dim strSession As String = GetSessionID().ToString + "_Pagos"
        Dim strFile As String = GetRutaFisica("temp/") + strSession + ".xml"
        vds.WriteXml(strFile, XmlWriteMode.WriteSchema)
    End Sub

    Public Shared Function CargarPagosCarrito(ByVal vdt As DataTable, _
                                                ByVal vstrConcepto As String, _
                                                ByVal vintCodPagina As Integer) As Integer
        Dim dsCarrito As DataSet = GetCarrito()
        Dim i As Integer = 0

        If dsCarrito Is Nothing Then
            dsCarrito = New DataSet
            dsCarrito.Tables.Add(GetEstructuraTablaCarrito.Copy)
        End If
        If dsCarrito.Tables.Count = 0 Then
            dsCarrito.Tables.Add(GetEstructuraTablaCarrito.Copy)
        End If
        For i = 0 To vdt.Rows.Count - 1
            If Not BuscarDocumentoCarrito(dsCarrito.Tables(0), CheckStr(vdt.Rows(i)("documento"))) Then
                dsCarrito.Tables(0).ImportRow(vdt.Rows(i))
            End If
        Next

        i = 0
        While i <= dsCarrito.Tables(0).Rows.Count - 1
            If Not BuscarDocumentoCarrito(vdt, CheckStr(dsCarrito.Tables(0).Rows(i)("documento"))) Then
                If vstrConcepto = CheckStr(dsCarrito.Tables(0).Rows(i)("sicodcre")) _
                    And vintCodPagina = CheckInt(dsCarrito.Tables(0).Rows(i)("num_pagina")) _
                    And GetAdministradoBuscado.ToLower.Replace(",", "") = CheckStr(dsCarrito.Tables(0).Rows(i)("datosimp")).ToLower.Replace(",", "") Then
                    dsCarrito.Tables(0).Rows.RemoveAt(i)
                Else
                    i += 1
                End If
            Else
                i += 1
            End If
        End While

        dsCarrito.AcceptChanges()
        SalvarCarrito(dsCarrito)
        Return 1
    End Function
    '''////////////////////////////////// FUNCIONES DJ /////////////////////////////////////////
    Public Shared Sub SalvarPapeletaDJ(ByVal vdt As DataTable)
        'Dim strSession As String = GetSessionID().ToString + "_" + GetConceptoReca.ToString()
        Dim strSession As String = GetSessionID().ToString + "_docdj"
        'Dim strFile As String = GetRutaFisica("temp/") + strSession + ".xml"
        Dim strFile As String = GetRutaFisica("~/temp/") + strSession + ".xml"

        vdt.WriteXml(strFile, XmlWriteMode.WriteSchema)
    End Sub
    Public Shared Function GetPapeletaDJ() As DataTable
        Dim strSession As String = GetSessionID().ToString + "_docdj"
        Dim dtDocDJ As New DataTable
        'Dim strFile As String = GetRutaFisica("temp/") + strSession + ".xml"
        Dim strFile As String = GetRutaFisica("~/temp/") + strSession + ".xml"

        If IO.File.Exists(strFile) Then
            dtDocDJ.ReadXml(strFile)
        End If
        Return dtDocDJ
    End Function
    Public Shared Function GetEstructuraTablaPapeleta() As DataTable
        Dim dt As New DataTable("dr_papeleta")
        '--- REGISTRAT DJ ------

        'iMovPag  null
        'siCodMun    1
        'cPapele 13096875     
        'cPapOri 13096875     
        'cPlaca  SOH540    
        'sdFecInf    2019 - 10 - 17 00: 00:00
        'sdFecNot    NULL
        'siTipDId    2
        'cDocIde 09785734    
        'cLicCon Q09785734   
        'siCodRgl    4
        'siCodBLe    34
        'cCodFal G29  
        'cRucCon NULL
        'iCanVehiculo    NULL
        'bCalDescuento   1
        'sdFecRevLicencia    NULL
        'siCodUsu    13316
        'sdFecAct    2019 - 10 - 22 00: 00:00
        'cNomTer VirtualSAT           


        dt.Columns.Add(New DataColumn("imovPag", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("siCodMun", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("cPapele", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("cPapOri", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("cPlaca", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("sdFecInf", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("sdFecNot", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("siTipDId", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("cDocIde", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("cLicCon", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("siCodRgl", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("siCodBLe", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("cCodFal", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("cRucCon", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("iCanVehiculo", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("bCalDescuento", Type.GetType("System.Int16")))
        dt.Columns.Add(New DataColumn("sdFecRevLicencia", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("siCodUsu", Type.GetType("System.Int32")))
        dt.Columns.Add(New DataColumn("sdFecAct", Type.GetType("System.String")))
        dt.Columns.Add(New DataColumn("cNomTer", Type.GetType("System.String")))

        dt.PrimaryKey = New DataColumn() {dt.Columns("cPapele")}
        Return dt
    End Function


    '''////////////////////////////////// FIN FUNCIONES DJ /////////////////////////////////////////

    Public Shared Function CargarPagosCarritoTransito(ByVal vdt As DataTable, ByVal vstrConcepto As String) As Integer
        Dim dsCarrito As DataSet = GetCarrito()
        Dim i As Integer = 0

        If dsCarrito Is Nothing Then
            dsCarrito = New DataSet
            dsCarrito.Tables.Add(GetEstructuraTablaCarrito.Copy)
        End If
        If dsCarrito.Tables.Count = 0 Then
            dsCarrito.Tables.Add(GetEstructuraTablaCarrito.Copy)
        End If
        For i = 0 To vdt.Rows.Count - 1
            If Not BuscarDocumentoCarrito(dsCarrito.Tables(0), CheckStr(vdt.Rows(i)("documento"))) Then
                dsCarrito.Tables(0).ImportRow(vdt.Rows(i))
            End If
        Next

        dsCarrito.AcceptChanges()
        SalvarCarrito(dsCarrito)

    End Function

    Public Shared Function BuscarDocumentoCarrito(ByVal vdt As DataTable, ByVal vstrDocumento As String) As Boolean
        If Not vdt Is Nothing Then
            For i As Integer = 0 To vdt.Rows.Count - 1
                If CheckStr(vdt.Rows(i)("documento")) = vstrDocumento Then
                    Return True
                End If
            Next
        End If
        Return False
    End Function

    Public Shared Function BuscarDocumentoCarrito(ByVal vstrDocumento As String) As Boolean
        Dim dsCarrito As DataSet = GetCarrito()
        If dsCarrito.Tables.Count > 0 Then
            With dsCarrito.Tables(0)
                For i As Integer = 0 To .Rows.Count - 1
                    If CheckStr(.Rows(i)("documento")) = CheckStr(vstrDocumento) Then
                        Return True
                    End If
                Next
            End With
        End If
        Return False
    End Function

    Public Shared Function GetDatosCarrito() As ArrayList
        Dim arrTemp As New ArrayList
        Dim dsCarrito As DataSet = GetCarrito()
        Dim dblTotal As Double = 0
        Dim intCantidad As Integer = 0
        If dsCarrito.Tables.Count > 0 Then
            With dsCarrito.Tables(0)
                intCantidad = .Rows.Count
                For i As Integer = 0 To intCantidad - 1
                    dblTotal += CheckDbl(.Rows(i)("monto"))
                Next
            End With
        End If
        arrTemp.Add(intCantidad)
        arrTemp.Add(dblTotal)
        Return arrTemp
    End Function

    Public Shared Function GetNombreReglamento(ByVal pintCodCre As Integer) As String
        Dim strNombre As String = ""
        Select Case pintCodCre
            Case 581
                strNombre = "RTU"
            Case 582
                strNombre = "RGT"
            Case 587
                strNombre = "RNT"
        End Select
        Return strNombre
    End Function

    Public Shared Sub ProcesarCarritoDerechos(ByVal varlValores As ArrayList)
        Dim i As Integer = 0
        Dim dtCarritoTemp As DataTable
        Dim dblMonto As Double = 0
        Dim strDocumento As String = ""
        Dim intCantidad As Integer = varlValores.Count
        Dim strConcepto As String = "DERECHOS"
        Dim arrValores() As String

        dtCarritoTemp = GetEstructuraTablaCarrito()
        For i = 0 To intCantidad - 1
            arrValores = CType(varlValores(i), String())
            strDocumento = CheckStr(arrValores(0))
            dblMonto = CheckInt(arrValores(1))

            If strDocumento <> "" And dblMonto > 0 Then
                Dim dr As DataRow
                dr = dtCarritoTemp.NewRow
                dr("id") = i
                dr("concepto") = strConcepto
                dr("referencia") = CheckStr(arrValores(2))
                dr("documento") = strDocumento
                dr("monto") = dblMonto
                dr("ncuota") = dblMonto
                dr("emision") = 0
                dr("reajuste") = 0
                dr("mora") = 0
                dr("importe") = 0
                dr("reinci") = 0
                dr("gastos") = 0
                dr("costas") = 0
                dr("descuento") = 0
                dr("sicodcre") = CheckDbl(arrValores(3))
                dr("anio") = Date.Today.Year
                dr("periodo") = Date.Today.Month
                dr("datosimp") = CheckStr(arrValores(4))
                dr("icodper") = 0
                dr("sdFecVen") = Nothing
                dr("iCodPre") = 0
                dr("num_pagina") = 0
                dr("derecho") = CheckStr(arrValores(0))

                dtCarritoTemp.Rows.Add(dr)
            End If

        Next
        CargarPagosCarrito(dtCarritoTemp, strConcepto, 0)

    End Sub

End Class
