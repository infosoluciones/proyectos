Option Explicit On
Option Strict On

Imports FuncionesWeb
Imports SAT.Funciones.Validaciones
Imports SAT

Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Response.Redirect(BuscarMensaje("pagina_login"))  'Comment-test-kgc
        If Not IsPostBack Then
            Inicio()
        End If
    End Sub

    Private Sub Inicio()

    End Sub

    Protected Sub btnEnviar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnEnviar.Click
        Dim strSesion As String = ""
        Dim intCodigo As Integer
        Dim oBLL As HomeSiteBLL.ConsultasWeb
        Dim intSession As Integer
        Dim strUsuario As String = CheckStr(Me.txtUsuario.Text)
        Dim strClave As String = CheckStr(Me.txtClave.Text)

        If strUsuario <> "" And strClave <> "" Then
            oBLL = New HomeSiteBLL.ConsultasWeb
            If True Then
                intSession = oBLL.GetCrearSesion(GetConexionSoporteWEB, intCodigo, Request.ServerVariables("REMOTE_HOST"))
                If intSession > 0 Then
                    strSesion = strUsuario + "|" + Date.Today.Day.ToString + "|" + intSession.ToString

                    oBLL = Nothing
                    Response.Redirect("principal.aspx?" + SetURL("mysession", strSesion))
                End If
            Else
                Me.lblMensajeServer.Text = "Correo o clave incorrecta."

            End If
        End If
        oBLL = Nothing


    End Sub

End Class
