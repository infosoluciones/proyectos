Option Explicit On
Option Strict On

Imports FuncionesWeb
Imports SAT.Funciones.Validaciones
Imports SAT
Imports CaptchaDLL
Imports System.IO

Partial Class Iniciolibre
    Inherits System.Web.UI.Page
    Private intCaptcha As Integer = 4

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            pInicio()

        End If
    End Sub

    Private Sub pInicio()
        Dim strUsuario As String = Request("uid") 'email o celular
        Dim strValidacion As String = Request("valida") 'dia del mes
        Dim strCodUsuario As String = Request("ncod") 'codigo de registro
        Dim strOrigen As String = Request("tipbus") 'strOrigen=3 -pitaz
        Dim strOrigen2 As String = Request("valbus") 'strOrigen=3 -pitaz
        Dim intPag As Integer = CInt(Request("pag")) 'pag=148 -papeleta

        Dim intCodUsuario As Integer = 0
        Dim strTipBus As String = GetURL("tipbus")
        Dim strValBus As String = GetURL("valbus")

        Session("codveh") = 0
        Session("icodper_buscado") = 0
        Session("vnombre_buscado") = ""

        If strOrigen = "3" Then
            strTipBus = strOrigen
        ElseIf strOrigen = "9"
            strTipBus = strOrigen
        End If

        If Not strUsuario Is Nothing And IsNumeric(strValidacion) Then
            Dim strSesion As String = ""
            Dim oBLL As HomeSiteBLL.ConsultasWeb
            Dim intSession As Integer
            strUsuario = strUsuario.Replace("|", "@")

            If strUsuario <> "" And IsNumeric(strCodUsuario) And CInt(strValidacion) = Date.Today.Day Then
                intCodUsuario = CInt(strCodUsuario)
                oBLL = New HomeSiteBLL.ConsultasWeb
                If True Then


                    intSession = oBLL.GetCrearSesion(GetConexionSoporteWEB, intCodUsuario, Request.ServerVariables("REMOTE_HOST"), "ESTADO_CUENTA")


                    If intSession > 0 Then
                        strSesion = strUsuario + "|" + _
                        Date.Today.Day.ToString + "|" + _
                        intSession.ToString + "|" + _
                        strCodUsuario + "|" + _
                        strTipBus + "|" + _
                        strValBus + "|"
                        oBLL = Nothing

                        '---LOG----
                        'registerLog("strUsuario=" + strUsuario)
                        'registerLog("strValidacion=" + strValidacion)
                        'registerLog("strCodUsuario=" + strCodUsuario)
                        'registerLog("strOrigen=" + strOrigen)
                        'registerLog("strOrigen2=" + strOrigen2)
                        'registerLog("tipbus=" + strTipBus)
                        'registerLog("valbus=" + strValBus)
                        'registerLog("GetConexionSoporteWEB=" + GetConexionSoporteWEB()) ' ok
                        'registerLog("intCodUsuario=" + CStr(intCodUsuario)) 'ok
                        'registerLog("REMOTE_HOST=" + Request.ServerVariables("REMOTE_HOST"))
                        'registerLog("intSession=" + CStr(intSession))
                        'registerLog("strSesion=" + strSesion)
                        '----

                        Response.Redirect("principal.aspx?" + SetURL("mysession", strSesion))

                    End If
                Else
                    Response.Redirect(BuscarMensaje("pagina_login"))
                End If
            Else
                Response.Redirect(BuscarMensaje("pagina_login"))
            End If
            oBLL = Nothing
        Else
            Response.Redirect(BuscarMensaje("pagina_login"))
        End If
    End Sub
End Class
