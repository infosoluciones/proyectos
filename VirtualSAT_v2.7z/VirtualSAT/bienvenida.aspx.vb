Option Explicit On
Option Strict On

Imports FuncionesWeb
Imports SAT.Funciones.Validaciones
Imports System.Data
Imports SAT.HomeSiteBLL
Imports SAT
Imports System.Configuration


Partial Class bienvenida
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            pProcesarBusqueda()
            Inicio()
        End If
    End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)
        Dim strDocumento As String = ""
        Dim intTipoDocu As Integer = 0

        msjAdventencia.Visible = False

        If intUsuario <> 0 Then ' Cuando se encuentre logeado
            ds = oBLL.BuscarUsuarioWEBxCodigo(GetConexionSoporteWEB, intUsuario)
            If ds.Tables(0).Rows.Count > 0 Then
                With ds.Tables(0).Rows(0)
                    strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
                    strDocumento = CheckStr(.Item("VNRODOC"))
                    intTipoDocu = CheckInt(.Item("TIPODOCEQ"))
                End With
            End If
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing
        If strDocumento <> "" Then
            BuscarContribuyente(strDocumento, intTipoDocu, strUsuario)
        End If
    End Sub

    ''' <summary>Permite redireccionar seg�n el tipo de b�squeda la p�gina correspondiente.</summary>
    ''' <remarks><list type="bullet">
    ''' <item><CreadoPor>.</CreadoPor></item>
    ''' <item><FecCrea>.</FecCrea></item></list>
    ''' <list type="bullet">
    ''' <item><FecActu>24/10/2017.</FecActu></item>
    ''' <item><Resp>Lucar Capristano Carrillo.</Resp></item>
    ''' <item><Mot>Se agrega tipo de consulta para redireccionar a la p�gina de Papeletas.</Mot></item></list></remarks>
    Private Sub pProcesarBusqueda()
        Dim strTipoBusqueda As String = GetTipBusqueda()
        Dim strValorBusqueda As String = GetValBusqueda()
        Dim intTipoDoc As Integer = 0
        Dim strUrl As String = String.Empty
        Select Case strTipoBusqueda
            Case "1" 'DNI / RUC
                If strValorBusqueda.Trim.Length = 8 Then
                    intTipoDoc = 2
                End If
                If strValorBusqueda.Trim.Length = 11 Then
                    intTipoDoc = 1
                End If
                If intTipoDoc > 0 Then
                    Redireccionar(Paginas.BuscadorTributos, SetUrlLibre("TRI", "T") + "&" + SetURL("tipdoc", intTipoDoc.ToString) + "&" + SetURL("valbus", strValorBusqueda))
                End If
            Case "2" 'Placa papeletas
                strUrl = GetNombrePagina(Paginas.Papeletas, SetURL("pla", strValorBusqueda))
                If strValorBusqueda.Trim <> "" And strValorBusqueda.ToLower <> "undefined"  Then
                    Session.Item("destPage") = strUrl
                    Redireccionar(Paginas.Cargando, "destPage=" + strUrl)
                End If
            Case "3" ' PITAZO
                Redireccionar(Paginas.PapeletasEmail)
            Case "4" 'Invitado segun concepto de reca de tributos
                Redireccionar(Paginas.BuscadorTributos, SetUrlLibre("TRI", strValorBusqueda))
            Case "5" 'Placa impuesto vehicular
                intTipoDoc = 3 'placa
                Redireccionar(Paginas.BuscadorTributos, SetUrlLibre("TRI", "V") + "&" + SetURL("tipdoc", intTipoDoc.ToString) + "&" + SetURL("valbus", strValorBusqueda))
            Case "6" 'Record
                Redireccionar(Paginas.Record)
            Case "7" 'B�squeda de capturas
                Redireccionar(Paginas.Capturas)
            Case "8" 'Consulta de Papeletas desde link externo
                strUrl = GetNombrePagina(Paginas.Papeletas, SetURL("pla", ""))
                Session.Item("destPage") = strUrl
                Redireccionar(Paginas.Cargando, "destPage=" + strUrl)
            Case "9" 'Registro de papeletas 
                'Redireccionar(Paginas.RegistraDIC)               
                Redireccionar(Paginas.RegistraDIC, SetURL("pap", strValorBusqueda))

        End Select

    End Sub

    Private Sub BuscarContribuyente(ByVal strDocumento As String, ByVal intTipoDocu As Integer, ByVal strNombrePersona As String)
        Dim oBLL As ConsultasVarias
        Dim objPorContactos As New SAT.WEB.BLL.PortalSAT.clsContactos
        Dim ds, ds1 As New DataSet
        Dim dsPersonaDatosContacto As DataSet = Nothing
        Dim strCodPer As String = ""
        Dim strPaswd As String = ""
        Dim strTelCasa1 As String = ""
        Dim strTelMovil1 As String = ""
        Dim strEMail1 As String = ""
        Dim intCodMun As Integer = SAT.Base.Lib.Datos.CheckInt(Resources.Parametros.strCodMunicipalidad)

        Try
            oBLL = New ConsultasVarias

            'Registro de busqueda-----------
            RegistroDetalleBusqueda(GetConexionSoporteWEB, "DOC:" + strDocumento, 0, Request.CurrentExecutionFilePath)

            '-------------------------------
            ds = oBLL.BuscarPersona(GetConexionSiatTributos, intTipoDocu, strDocumento)

            Me.lblMensaje.Text = ""
            If Not ds Is Nothing Then
                If ds.Tables(0).Rows.Count > 0 Then
                    With ds.Tables(0).Rows(0)
                        strCodPer = CheckStr(.Item("iCodPer"))
                        strPaswd = CheckStr(.Item("vPasswd"))
                    End With

                    dsPersonaDatosContacto = objPorContactos.BuscarPersonaxCodigoPassword(GetConexionSiatTributos, intCodMun, CheckInt(strCodPer), strPaswd)

                    If dsPersonaDatosContacto.Tables(0).Rows.Count <> 0 Then

                        For Each dwFila As DataRow In dsPersonaDatosContacto.Tables(0).Rows
                            strTelCasa1 = dwFila("cTelefo").ToString
                            strTelMovil1 = dwFila("cTelef2").ToString
                            strEMail1 = dwFila("cEMail").ToString
                        Next
                        If strTelCasa1 = "" Or strTelMovil1 = "" Or strEMail1 = "" Then
                            msjAdventencia.Visible = True
                            Me.lblMensaje.Text = "Estimado " + strNombrePersona + ", mantener su informaci�n actualizada es importante para nosotros, por favor ingrese "

                        End If
                    Else
                        msjAdventencia.Visible = True
                        Me.lblMensaje.Text = "Estimado " + strNombrePersona + ", mantener su informaci�n actualizada es importante para nosotros, por favor ingrese "
                    End If
                End If

            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            ds = Nothing
            dsPersonaDatosContacto = Nothing
            oBLL = Nothing
            objPorContactos = Nothing
        End Try

    End Sub

    Private Sub Reedirecciona(ByVal strUsuario As String, ByVal strPassword As String, ByVal strDocumento As String, ByVal intTipoDocu As Integer, ByVal strNombrePersona As String)
        Dim objPorContactos As New SAT.WEB.BLL.PortalSAT.clsContactos
        Dim dsPersona As DataSet = Nothing
        Dim dsPersonaDatosContacto As DataSet = Nothing
        Dim striCodPer As String = Nothing
        Dim strTelCasa1 As String = Nothing
        Dim strTelMovil1 As String = Nothing
        Dim strEMail1 As String = Nothing


        Dim intCodMun As Integer = SAT.Base.Lib.Datos.CheckInt(Resources.Parametros.strCodMunicipalidad)

        Try
            dsPersona = objPorContactos.BuscarPersonaxCodigoPassword(GetConexionSiatTributos, intCodMun, SAT.Base.Lib.Datos.CheckInt(strUsuario), strPassword)
            If dsPersona.Tables(0).Rows.Count <> 0 Then
                'Ha retornado una persona

                Me.lblMensaje.Text = ""
                For Each dwFila As DataRow In dsPersona.Tables(0).Rows
                    striCodPer = dwFila("iCodPer").ToString
                Next

                dsPersonaDatosContacto = objPorContactos.BuscarPersonaxCodigoEnWeb(GetConexionSoporteWEB, CheckInt(striCodPer), 0)

                If dsPersonaDatosContacto.Tables(0).Rows.Count <> 0 Then
                    'Ha retornado una persona

                    Me.lblMensaje.Text = ""
                    For Each dwFila As DataRow In dsPersonaDatosContacto.Tables(0).Rows
                        strTelCasa1 = dwFila("cTelCasa1").ToString
                        strTelMovil1 = dwFila("cTelMovil1").ToString
                        strEMail1 = dwFila("cEMail1").ToString
                    Next
                    If strTelCasa1 = "" Or strTelMovil1 = "" Or strEMail1 = "" Then
                        msjAdventencia.Visible = True
                        Me.lblMensaje.Text = "Estimado " + strNombrePersona + ", mantener su informaci�n actualizada es importante para nosotros, por favor ingrese "
                    End If

                Else
                    msjAdventencia.Visible = True
                    Me.lblMensaje.Text = ""
                    Me.lblMensaje.Text = "Estimado " + strNombrePersona + ", mantener su informaci�n actualizada es importante para nosotros, por favor ingrese "
                End If


            End If

        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not dsPersona Is Nothing Then dsPersona.Dispose()
            objPorContactos = Nothing
        End Try
    End Sub
End Class
