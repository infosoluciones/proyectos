Imports SAT.HomeSiteBLL
Imports System.Data
Imports FuncionesWeb
Imports SAT.Funciones.Validaciones

Partial Class controles_opciones
    Inherits System.Web.UI.UserControl

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Inicio()
        End If
    End Sub

    Private Sub Inicio()
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim drrModulos As IDataReader
        Dim strPath As String
        Dim newNodePadre As TreeNode
        Dim strURL As String = ""
        Dim strParametro As String = ""

        strPath = Request.ApplicationPath
        drrModulos = oBLL.BuscarModulosWeb(FuncionesWeb.GetConexionSoporteWEB, GetCodigoRegistroUsuario, GetTipBusqueda)
        newNodePadre = Nothing
        While drrModulos.Read
            Dim newNode As TreeNode
            If CheckStr(drrModulos("tiene_sub")) = "S" Then
                newNode = New TreeNode(CStr(drrModulos("titulo")), _
                            CStr(drrModulos("modulo_id")), _
                            Nothing, Nothing, _
                            Nothing)
                If CheckStr(drrModulos("url_imagen")) <> "" Then
                    newNode.ImageUrl = strPath + CStr(drrModulos("url_imagen"))
                End If
                newNode.ToolTip = CStr(drrModulos("descripcion"))
                newNode.SelectAction = TreeNodeSelectAction.Expand
                newNode.PopulateOnDemand = False
                Me.treMenu.Nodes.Add(newNode)
                newNodePadre = newNode
            Else
                If CheckStr(drrModulos("ruta")).StartsWith("http") Then
                    strURL = CheckStr(drrModulos("ruta"))
                Else                    
                    strURL = strPath + CheckStr(drrModulos("ruta"))
                End If
                strParametro = CheckStr(drrModulos("parametro"))
                If strParametro <> "" Then
                    strURL += "?" + strParametro + "&mysession=" + Web.HttpUtility.UrlEncodeUnicode(MySessionID)
                Else
                    strURL += "?mysession=" + Web.HttpUtility.UrlEncodeUnicode(MySessionID)
                End If

                newNode = New TreeNode(CheckStr(drrModulos("titulo")), _
                            CheckStr(drrModulos("modulo_id")), _
                            Nothing, strURL, _
                            CheckStr(drrModulos("target")))
                newNode.ToolTip = CStr(drrModulos("descripcion"))
                If Not newNodePadre Is Nothing Then
                    newNodePadre.ChildNodes.Add(newNode)
                End If
            End If

        End While
        Me.treMenu.ExpandAll()
        oBLL = Nothing
        drrModulos.Close()
        drrModulos.Dispose()
        drrModulos = Nothing
    End Sub

End Class
