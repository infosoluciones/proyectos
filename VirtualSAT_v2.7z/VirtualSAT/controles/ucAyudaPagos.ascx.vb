
Partial Class controles_ucAyudaPagos
    Inherits System.Web.UI.UserControl

End Class
