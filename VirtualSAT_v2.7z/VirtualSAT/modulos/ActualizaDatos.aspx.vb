Option Explicit On
Option Strict On

Imports SAT
Imports SAT.Funciones.Validaciones
Imports System.Data
Imports SAT.HomeSiteBLL
Imports FuncionesWeb
Imports CaptchaDLL

Partial Class modulos_ActualizaDatos
    Inherits System.Web.UI.Page
    Dim mstrTipDoc As String
    Dim mstrValBus As String
    Private intCaptcha As Integer = 4

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ValidarPagina()
        If Not IsPostBack Then
            Inicio()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
        End If
    End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)
        Dim strDocumento As String = ""
        Dim intTipoDocu As Integer = 0
        Dim sUrl As String = ""
        Dim sScript As String = ""
        msjErr.Visible = False

        ds = oBLL.BuscarUsuarioWEBxCodigo(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
                strDocumento = CheckStr(.Item("VNRODOC"))
                intTipoDocu = CheckInt(.Item("TIPODOCEQ"))
            End With
        End If

        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing

        If strDocumento = "" Then
            sUrl = ConfigurationManager.AppSettings("strUrlWebsiteV8Logeo").ToString()

            Response.Redirect(ConfigurationManager.AppSettings("strUrlWebsiteV8Logeo").ToString(), False)


        Else
            BuscarContribuyente(strDocumento, intTipoDocu)
        End If

    End Sub

    Private Sub BuscarContribuyente(ByVal strDocumento As String, ByVal intTipoDocu As Integer)
        Dim oBLL As ConsultasVarias
        Dim ds As New DataSet
        Dim strCodPer As String = ""
        Dim strPaswd As String = ""
        oBLL = New ConsultasVarias
        Try

            RegistroDetalleBusqueda(GetConexionSoporteWEB, "DOC:" + strDocumento, 0, Request.CurrentExecutionFilePath)
            '-------------------------------
            ds = oBLL.BuscarPersona(GetConexionSiatTributos, intTipoDocu, strDocumento)

            If Not ds Is Nothing Then
                If ds.Tables(0).Rows.Count > 0 Then
                    With ds.Tables(0).Rows(0)

                        strCodPer = CheckStr(.Item("iCodPer"))
                        strPaswd = CheckStr(.Item("vPasswd"))
                    End With
                End If
            End If


            Reedirecciona(strCodPer, strPaswd, strDocumento, intTipoDocu)


        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            ds = Nothing
            oBLL = Nothing
        End Try

    End Sub

    Private Sub Reedirecciona(ByVal strUsuario As String, ByVal strPassword As String, ByVal strDocumento As String, ByVal intTipoDocu As Integer)
        Dim objPorContactos As New SAT.WEB.BLL.PortalSAT.clsContactos
        Dim dsPersona As DataSet = Nothing
        Dim dtPersona As DataTable = Nothing
        Dim striCodPer As String = Nothing
        Dim sUrl As String = ""
        Dim sScript As String = ""
        Dim intCodMun As Integer = SAT.Base.Lib.Datos.CheckInt(Resources.Parametros.strCodMunicipalidad)

        Try
            dsPersona = objPorContactos.BuscarPersonaxCodigoPassword(GetConexionSiatTributos, intCodMun, SAT.Base.Lib.Datos.CheckInt(strUsuario), strPassword)
            If dsPersona.Tables(0).Rows.Count <> 0 Then

                Me.lblMensaje.Text = ""
                For Each dwFila As DataRow In dsPersona.Tables(0).Rows
                    striCodPer = dwFila("iCodPer").ToString
                Next

                Dim strAutentica As String = striCodPer & "|" & strPassword & "|vs"
                Dim strAutenticaEncriptada As String = FuncionesWeb.SetURL("P", strAutentica)

                sUrl = ConfigurationManager.AppSettings("strUrlWebsiteV8ActualizaDatos").ToString() & strAutenticaEncriptada

                Response.Redirect(ConfigurationManager.AppSettings("strUrlWebsiteV8ActualizaDatos").ToString() & strAutenticaEncriptada, True)


            Else
                msjErr.Visible = True
                Me.lblMensaje.Text = "El DNI " + strDocumento + " no es contribuyente del SAT de Lima"

            End If

        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not dsPersona Is Nothing Then dsPersona.Dispose()
            objPorContactos = Nothing
        End Try
    End Sub

End Class
