Option Explicit On
Option Strict On

Imports SAT
Imports SAT.Funciones.Validaciones
Imports System.Data
Imports SAT.HomeSiteBLL
Imports FuncionesWeb
Imports CaptchaDLL

Partial Class modulos_BusquedaTributario
    Inherits System.Web.UI.Page
    Dim mstrTipDoc As String
    Dim mstrValBus As String
    Private intCaptcha As Integer = 4

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ValidarPagina()
        If Not IsPostBack Then
            Inicio()
            BusquedaInicial()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
        End If
        MostraOcultarPlaca()
    End Sub

    Private Sub MostraOcultarPlaca()
        If GetConceptoReca() = 146 Then
            Me.divBuscaPlaca.Visible = True
            Me.optBuscaPlaca.Visible = True
        Else
            Me.divBuscaPlaca.Visible = False
            Me.optBuscaPlaca.Visible = False
        End If
    End Sub

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing

        Me.lblTitulo.Text = GetConceptoDescripcion().ToUpper
        Me.lblTitGrid.Visible = False
        'Me.txtPlaca.Attributes.Add("onkeypress", "return clickButton(event,'" + Me.btnBuscaPlaca.ClientID + "')")
        'Me.txtCodigoAdmin.Attributes.Add("onkeypress", "return clickButton(event,'" + Me.btnBuscaCodigo.ClientID + "')")
        'Me.txtDocumento.Attributes.Add("onkeypress", "return clickButton(event,'" + Me.btnBuscaDocumento.ClientID + "')")
        'Me.txtPlaca.Attributes.Add("onkeypress", "return clickButton(event,'" + Me.btnBuscaPlaca.ClientID + "')")

        Me.txtPaterno.Attributes.Add("onkeypress", "return desabilitaEnter(event)")
        Me.txtMaterno.Attributes.Add("onkeypress", "return desabilitaEnter(event)")
        Me.txtNombre.Attributes.Add("onkeypress", "return desabilitaEnter(event)")
        Me.txtRazon.Attributes.Add("onkeypress", "return desabilitaEnter(event)")

        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
        LimpiarTodo()

    End Sub

    Private Sub Mantenimiento()
        Me.lblMensajePrico.Text = "P�gina en mantenimiento, disculpe las molestias."
        MostrarOcultarDivBusqueda(False)
    End Sub

    Private Sub BusquedaInicial()
        mstrTipDoc = GetURL("tipdoc")
        mstrValBus = GetURL("valbus")
        Select Case mstrTipDoc
            Case "1", "2"
                ddlTipoDocu.SelectedValue = mstrTipDoc
                Me.txtDocumento.Text = mstrValBus
                ' BuscaxDocumento()
            Case "3"
                Me.txtPlaca.Text = mstrValBus
                ' BuscaInicioxPlaca()
        End Select
    End Sub

    Private Sub LimpiarTodo()
        Me.txtCodigoAdmin.Text = ""
        Me.txtDocumento.Text = ""
        Me.txtPaterno.Text = ""
        Me.txtMaterno.Text = ""
        Me.txtNombre.Text = ""
        Me.txtRazon.Text = ""
        Me.txtCaptcha.Text = ""
        Me.hidMaterno.Value = ""
        Me.hidNombre.Value = ""
        Me.hidPaterno.Value = ""
        Me.hidRazon.Value = ""        
        Me.grdAdministrados.DataSource = Nothing
        Me.grdAdministrados.DataBind()
        Me.lblMensajeCantidad.Text = ""
        Me.btnNuevaBusqueda.Visible = False
        Me.lblTitGrid.Visible = False
        Session("codveh") = 0
        Session("icodper_buscado") = 0
        Session("vnombre_buscado") = ""
    End Sub

    Private Sub BuscarPersona()
        Dim strPaterno, strMaterno, strNombres As String
        Dim strRazon As String
        Dim strDocumento As String = CheckStr(Me.txtDocumento.Text)
        Dim oBLL As ConsultasVarias
        Dim ds As New DataSet

        strPaterno = Me.hidPaterno.Value
        strMaterno = Me.hidMaterno.Value
        strNombres = Me.hidNombre.Value
        strRazon = Me.hidRazon.Value
        oBLL = New ConsultasVarias

        If IsNumeric(Me.txtCodigoAdmin.Text) Then
            'Registro de busqueda-----------
            RegistroDetalleBusqueda(GetConexionSoporteWEB, "COD:" + Me.txtCodigoAdmin.Text, 0, Request.CurrentExecutionFilePath)
            '-------------------------------
            ds = oBLL.BuscarPersona(GetConexionSiatTributos, CInt(Me.txtCodigoAdmin.Text))
        End If
        If strDocumento <> "" Then
            'Registro de busqueda-----------
            RegistroDetalleBusqueda(GetConexionSoporteWEB, "DOC:" + strDocumento, 0, Request.CurrentExecutionFilePath)
            '-------------------------------
            ds = oBLL.BuscarPersona(GetConexionSiatTributos, CheckInt(Me.ddlTipoDocu.SelectedValue), strDocumento)
        End If
        If strPaterno <> "" And strMaterno <> "" Then
            'Registro de busqueda-----------
            RegistroDetalleBusqueda(GetConexionSoporteWEB, "APE:" + strPaterno + " " + strMaterno + ", " + strNombres, 0, Request.CurrentExecutionFilePath)
            '-------------------------------
            ds = oBLL.BuscarPersona(GetConexionSiatTributos, strPaterno, strMaterno, strNombres)
        End If
        If strRazon <> "" And strRazon.Length > 4 Then
            'Registro de busqueda-----------
            RegistroDetalleBusqueda(GetConexionSoporteWEB, "RAZ:" + strRazon, 0, Request.CurrentExecutionFilePath)
            '-------------------------------
            ds = oBLL.BuscarPersona(GetConexionSiatTributos, strRazon)
        End If
        If Not ds Is Nothing Then
            If ds.Tables.Count > 0 Then
                Me.grdAdministrados.DataSource = ds.Tables(0)
                Me.grdAdministrados.DataBind()
                Me.lblTitGrid.Visible = True
                Me.lblMensajeCantidad.Text = "Se encontraron " + ds.Tables(0).Rows.Count.ToString + " coincidencias para su b�squeda."
            End If
        End If
        ds = Nothing
        oBLL = Nothing
        MostrarOcultarDivBusqueda(False)
        Me.btnNuevaBusqueda.Visible = True
    End Sub

    Private Sub MostrarOcultarDivBusqueda(ByVal vbolMostrar As Boolean)
        Me.divOpciones.Visible = vbolMostrar
    End Sub

    Protected Sub grdAdministrados_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdAdministrados.PageIndexChanging
        grdAdministrados.PageIndex = e.NewPageIndex
        BuscarPersona()
    End Sub

    Protected Sub grdAdministrados_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles grdAdministrados.SelectedIndexChanged
        Dim strCodigo As String = ""
        Dim strNombre As String = ""
        Dim bolPrico As Boolean = False
        Dim strCodVeh() As String
        Dim intCodVeh As Integer = 0

        strCodigo = CType(grdAdministrados.SelectedRow.FindControl("lnkCodigo"), LinkButton).Text
        strNombre = CType(grdAdministrados.SelectedRow.FindControl("lnkNombre"), LinkButton).Text

        SetCodigoBuscado(strCodigo)
        SetAdministradoBuscado(strNombre)

        'If BuscarPrico(GetConexionSiatTributos, CInt(strCodigo), GetConceptoReca) Then
        '    If CheckStr(Me.hidCodVeh.Value) = "" Then
        '        MostrarOcultarDivBusqueda(False)
        '        Me.btnNuevaBusqueda.Visible = True
        '        Me.lblMensajePrico.Text = "Por su condici�n de Principal Contribuyente, le pedimos comunicarse con su sectorista para obtener su estado de cuenta."
        '        bolPrico = True
        '        Exit Sub
        '    End If
        'End If
        If Not bolPrico Then
            strCodVeh = Me.hidCodVeh.Value.Split("*"c)
            If strCodVeh.Length >= grdAdministrados.Rows.Count Then
                If IsNumeric(strCodVeh(grdAdministrados.SelectedIndex)) Then
                    intCodVeh = CInt(strCodVeh(grdAdministrados.SelectedIndex))
                End If
            End If
            RedirectDeuda(CType(strCodigo, Int32), intCodVeh)
            Response.End()
        End If

    End Sub

    Protected Sub btnNuevaBusqueda_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNuevaBusqueda.Click
        MostrarOcultarDivBusqueda(True)
        LimpiarTodo()
        Me.filter_div.Visible = True
        Me.btnNuevaBusqueda.Visible = False
    End Sub

    Protected Sub ibtnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    Protected Sub CaptchaContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CaptchaContinue.Click
        GestionarConsulta()
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    Private Sub BuscaInicioxPlaca()
        Dim strTemp As String = ValidaCadena(Me.txtPlaca.Text)
        If strTemp = "" Then Me.lblMensajeDocumento.Text = "Placa incorrecta" : Exit Sub
        LimpiarTodo()
        Me.txtPlaca.Text = strTemp
        BuscaPlaca()
    End Sub

    Private Sub BuscaxDocumento()
        Dim strTemp As String = ValidaCadena(Me.txtDocumento.Text)
        If strTemp = "" Then Me.lblMensajeDocumento.Text = "Documento incorrecto" : Exit Sub
        LimpiarTodo()
        Me.txtDocumento.Text = strTemp
        BuscarPersona()
    End Sub

    Private Sub RedirectDeuda(ByVal vintCodPer As Integer, ByVal vintCodVeh As Integer)
        If GetUrlLibre("tri") = "T" Then
            Redireccionar(Paginas.TributarioResumen, _
                SetUrlLibre("tri", GetUrlLibre("tri")) + "&" + _
                SetURL("cod", vintCodPer.ToString) + "&" + _
                SetURL("codveh", vintCodVeh.ToString))
        Else
            Redireccionar(Paginas.EstadoCuentaTributario, _
                SetUrlLibre("tri", GetUrlLibre("tri")) + "&" + _
                SetURL("cod", vintCodPer.ToString) + "&" + _
                SetURL("codveh", vintCodVeh.ToString) + "&" + _
                SetURL("pla", Me.hidPlaca.Value))
        End If
    End Sub

    Private Sub BuscaPlaca()
        Dim strPlaca As String = ValidaCadena(Me.txtPlaca.Text).ToUpper.Replace("-", "").Replace(" ", "")
        Dim oBLL As ConsultasVarias
        Dim ds As DataSet
        'Registro de busqueda-----------
        RegistroDetalleBusqueda(GetConexionSoporteWEB, "PLA:" + strPlaca, 0, Request.CurrentExecutionFilePath)
        '-------------------------------
        If strPlaca.Length > 4 Then
            oBLL = New ConsultasVarias
            ds = oBLL.BuscarPropietarioPorPlaca3(GetConexionSiatTributos, strPlaca)
            If ds.Tables.Count > 0 Then
                Me.grdAdministrados.DataSource = ds.Tables(0)
                Me.grdAdministrados.DataBind()
                Me.lblTitGrid.Visible = True
                Me.lblMensajeCantidad.Text = "Se encontraron " + ds.Tables(0).Rows.Count.ToString + " coincidencias para su b�squeda."
                If ds.Tables(0).Columns.Contains("iCodVeh") Then
                    If ds.Tables(0).Rows.Count > 0 Then
                        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
                            Me.hidCodVeh.Value += CheckStr(ds.Tables(0).Rows(i)("iCodVeh")) + "*"
                        Next
                    Else
                        Me.hidCodVeh.Value = ""
                    End If
                End If
            End If
            MostrarOcultarDivBusqueda(False)
            Me.hidPlaca.Value = strPlaca
            Me.btnNuevaBusqueda.Visible = True
        Else
            Me.lblMensajePlaca.Text = Resources.Parametros.strMsjPlacaIncorrecta
        End If
        ds = Nothing
        oBLL = Nothing
    End Sub

    '''<summary>M�todo para validar el c�digo captcha.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>11/02/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Function fbln_ValidarCaptha() As Boolean
        Dim blnRespuesta As Boolean
        If Session("CaptchaImageText") IsNot Nothing AndAlso txtCaptcha.Text.ToLower() = Session("CaptchaImageText").ToString().ToLower() Then
            blnRespuesta = True
            Me.filter_div.Visible = False
        Else
            Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
            Me.filter_div.Visible = True
        End If
        Return blnRespuesta
    End Function

    '''<summary>M�todo para ejecutar las consultas en base al tipo de consulta.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Sub GestionarConsulta()
        If (Me.hidTipConsulta.Value = "busqCodAdministrado") Then
            If fbln_ValidarCaptha() Then
                Dim strTemp As String = ValidaCadena(Me.txtCodigoAdmin.Text)
                If strTemp = "" Then Me.lblMensajeCodigo.Text = Resources.Parametros.strMsjCodIncorrecto : Exit Sub
                If Not IsNumeric(strTemp) Then Me.lblMensajeCodigo.Text = Resources.Parametros.strMsjCodIncorrecto : Exit Sub
                LimpiarTodo()
                Me.txtCodigoAdmin.Text = strTemp
                Me.lblMensajeCodigo.Text = Nothing
                BuscarPersona()
            Else
                Me.lblMensajeCodigo.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
        End If

        If (Me.hidTipConsulta.Value = "busqTipoDocIdentidad") Then
            If fbln_ValidarCaptha() Then
                Me.lblMensajeDocumento.Text = Nothing
                BuscaxDocumento()
            Else
                Me.lblMensajeDocumento.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
        End If

        If (Me.hidTipConsulta.Value = "busqApellidosNombres") Then
            If fbln_ValidarCaptha() Then
                Dim strPaterno, strMaterno, strNombres As String
                strPaterno = ValidaCadena(Me.txtPaterno.Text)
                strMaterno = ValidaCadena(Me.txtMaterno.Text)
                strNombres = ValidaCadena(Me.txtNombre.Text)
                If strPaterno.Length < 3 Or strMaterno.Length < 3 Then
                    Me.lblMensajeApellidos.Text = Resources.Parametros.strMsjApePat
                    Exit Sub
                End If
                LimpiarTodo()
                Me.txtPaterno.Text = strPaterno
                Me.txtMaterno.Text = strMaterno
                Me.txtNombre.Text = strNombres
                Me.hidPaterno.Value = strPaterno
                Me.hidMaterno.Value = strMaterno
                Me.hidNombre.Value = strNombres
                Me.lblMensajeApellidos.Text = Nothing
                BuscarPersona()
            Else
                Me.lblMensajeApellidos.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
        End If

        If (Me.hidTipConsulta.Value = "busqRazonSocial") Then
            If fbln_ValidarCaptha() Then
                Dim strRazon As String = ValidaCadena(Me.txtRazon.Text)
                Me.lblMensajeRazon.Text = Nothing
                If strRazon = "" Then Me.lblMensajeRazon.Text = Resources.Parametros.strMsjRazSocial : Exit Sub
                LimpiarTodo()
                Me.txtRazon.Text = strRazon
                Me.hidRazon.Value = strRazon
                BuscarPersona()
            Else
                Me.lblMensajeRazon.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
        End If
        If (Me.hidTipConsulta.Value = "divBuscaPlaca") Then
            If fbln_ValidarCaptha() Then
                Me.lblMensajePlaca.Text = Nothing
                BuscaPlaca()
            Else
                Me.lblMensajePlaca.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
        End If

    End Sub

End Class
