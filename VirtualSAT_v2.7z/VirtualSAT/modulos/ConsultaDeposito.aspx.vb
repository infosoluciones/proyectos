Option Explicit On
Option Strict

Imports SAT.SIAT.BLL.TDepositos
Imports System.Data
Imports FuncionesWeb
Imports SAT.Funciones.Validaciones
Imports SAT.SIAT.MOD.Depositos
Imports SAT.SIAT.BLL.Depositos
Imports SAT.SIAT.BLL.TGeneral
Imports SAT.HomeSiteBLL
Imports CaptchaDLL

Partial Class modulos_ConsultaDeposito
    Inherits System.Web.UI.Page

    Private intCaptcha As Integer = 4
    Private dblTotPre As Double = 0.0

#Region "M�todos"

    Private Sub pBuscarDatosInternamiento()
        'If Not fbln_ValidarDatosBusqueda() Then Exit Sub (Validar n�mero de placa)
        Dim objTBolIntBN As New clsTBolIntBN
        Dim modDepositos As New mod_depositos
        Dim dsBolInt As New DataSet
        Dim intCodigoMunicipalidad As Integer = GetCodigoMunicipalidad()
        Dim intCodigoDeposito As Integer = GetCodigoDeposito()
        Dim intTipoOpracion As String = GetTipoOperacion()
        Dim intGrua As Integer = GetGrua()
        Dim strPlaca As String = CheckStr(Replace(txtPlaca.Text.ToUpper, "-", ""))
        Dim strFecIni As String = ""
        Dim strFecTer As String = ""
        Dim dv As New DataView
        'Dim vds As New DataSet

        If strPlaca.Length > 5 Then
            Try
                Using objTBolIntBN
                    Using dsBolInt
                        dsBolInt = objTBolIntBN.Consultar_BoletaInternamiento(intCodigoMunicipalidad, _
                                                                              intCodigoDeposito, _
                                                                              strPlaca, _
                                                                              strFecIni, _
                                                                              strFecTer, _
                                                                              intTipoOpracion, _
                                                                              False)
                        If GetNroRegistros(dsBolInt) > 0 Then
                            dv = dsBolInt.Tables(0).DefaultView
                            dv.RowFilter = "iNumAtr = 30"
                            dsBolInt.Tables.Clear()
                            dsBolInt.Tables.Add(dv.ToTable)
                            dsBolInt.AcceptChanges()


                            If GetNroRegistros(dsBolInt) > 0 Then
                                modDepositos.sicodmun = intCodigoMunicipalidad
                                modDepositos.cnumbin = CheckStr(dsBolInt.Tables(0).Rows(0).Item("cNumBIn"))
                                modDepositos.cplaca = CheckStr(dsBolInt.Tables(0).Rows(0).Item("cPlaca"))
                                modDepositos.sdfecint = CheckStr(dsBolInt.Tables(0).Rows(0).Item("sdFecInt"))
                                modDepositos.cpapele = CheckStr(dsBolInt.Tables(0).Rows(0).Item("cPapele"))
                                modDepositos.ccodfal = CheckStr(dsBolInt.Tables(0).Rows(0).Item("cCodFal"))
                                hidPlacaNueva.Value = CheckStr(dsBolInt.Tables(0).Rows(0).Item("cPlacaNue"))
                                hidPlacaAntigua.Value = CheckStr(dsBolInt.Tables(0).Rows(0).Item("cPlacaAnt"))
                                modDepositos.siCodDep = CheckInt(dsBolInt.Tables(0).Rows(0).Item("siCodDps"))
                                hidDesDeposito.Value = CheckStr(dsBolInt.Tables(0).Rows(0).Item("cDesDep"))
                                hidCodDep.Value = CheckStr(dsBolInt.Tables(0).Rows(0).Item("siCodDps"))
                                Me.lnkMapa1.NavigateUrl = "#"
                                Me.lnkMapa1.Attributes.Add("onClick", "javascript:MostrarMapa('" & modDepositos.siCodDep & "')")

                                Call pInicio(modDepositos)
                                Mostrar()
                            Else
                                Me.lblMensajeVacio.Text = "La placa " & strPlaca.ToUpper & " no se  encuentra internado en el dep�sito del SAT."
                                Ocultar()
                                Limpiar()

                            End If

                        Else

                            Me.lblMensajeVacio.Text = "La placa " & strPlaca & " no se  encuentra internado en el dep�sito del SAT."
                            Ocultar()
                            Limpiar()
                        End If
                    End Using
                End Using

            Catch
                Throw
            Finally
                If Not dsBolInt Is Nothing Then dsBolInt.Dispose()

                dsBolInt = Nothing
                objTBolIntBN = Nothing
            End Try
        Else
            lblMensaje.Text = "Por favor ingrese el n�mero de placa correcta"
            Ocultar()
        End If
    End Sub

    Private Sub Mostrar()
        pnContenedor.Visible = True
        lblIndicaciones.Visible = True
    End Sub

    Private Sub Ocultar()
        pnContenedor.Visible = False
        lblIndicaciones.Visible = False
    End Sub

    Private Sub Limpiar()
        hidPlacaNueva.Value = ""
        hidPlacaAntigua.Value = ""
        hidDesDeposito.Value = ""
        hidCodDep.Value = ""
    End Sub

    Private Sub pInicio(ByVal vmodDepositos As mod_depositos)
        Dim objTActSecConBN As New clsTActSecConBN
        Dim objActSecConBN As New clsActSecConBN

        Dim ds As New DataSet
        Dim dsActEmb As New DataSet
        Dim dsDocDeu As New DataSet
        Dim dsDeuNTrib As New DataSet
        Dim dsCosTran As New DataSet
        Dim dsDeuTrib As New DataSet
        Dim dsCosTrib As New DataSet
        Dim dsDerSAT As New DataSet
        Dim dsActSec As New DataSet

        Dim intCodMun As Integer = vmodDepositos.sicodmun
        Dim strcNumBIn As String = vmodDepositos.cnumbin
        Dim strcNumAEm As String = ""
        Dim strCadena As String = ""
        Dim strPlaca As String = ""
        Dim strFecPag As String = GetFechaCorta()
        Dim i As Integer = 0
        Dim j As Integer = 0
        Dim dblDeuda As Double = 0.0
        Dim dblDeuTra As Double = 0.0
        Dim dblDeuTri As Double = 0.0
        Dim dblDerLib As Double = 0.0
        Dim dblDerGua As Double = 0.0
        Dim dblDerGru As Double = 0.0
        Dim dblCosTrib As Double = 0.0
        Dim dblCosTran As Double = 0.0
        Dim dblCosMult As Double = 0.0
        Dim dblPapPre As Double = 0.0
        Dim dblInfDir As Double = 0.0

        Dim intCodDeposito As Integer

        Dim strTextoMTC As String
        Dim strPlacaMostrar As String

        Dim strcNumDoc As String = ""
        Me.lblFecha.Text = GetFecha()

        Try
            Me.lblcNumBIn.Text = vmodDepositos.cnumbin
            dsActEmb = objTActSecConBN.Consultar_ActaSecuestroConservativo(intCodMun, strcNumBIn)
            If GetNroRegistros(dsActEmb) > 0 Then
                For Each dRow As DataRow In dsActEmb.Tables(0).Rows
                    strcNumAEm = CheckStr(dRow.Item("cNumAEm"))

                    ' Consulta de Documentos de Deuda No Tributario
                    dsDocDeu = objTActSecConBN.Consultar_DocumentosDeudaNoTributario(intCodMun, strcNumAEm, "(2,3)")
                    If GetNroRegistros(dsDocDeu) > 0 Then
                        strCadena = "In ("
                        strPlaca = CheckStr(dsDocDeu.Tables(0).Rows(0).Item("cPlaca"))
                        For Each dRowDeu As DataRow In dsDocDeu.Tables(0).Rows
                            strCadena += "'" & CheckStr(dRowDeu.Item("cNumDoc")) & "',"
                        Next
                        strCadena = Mid(strCadena, 1, Len(strCadena) - 1)
                        strCadena = strCadena + ")"

                        ' Consulta de Deuda No Tributaria
                        dsDeuNTrib = objActSecConBN.Consultar_DeudaNoTributario(intCodMun, strPlaca, strCadena, strFecPag)
                        If GetNroRegistros(dsDeuNTrib) > 0 Then
                            For Each dRowDeu As DataRow In dsDeuNTrib.Tables(0).Rows
                                If strcNumDoc <> CheckStr(dRowDeu.Item("cNumDoc").ToString) Then
                                    dblDeuTra += CheckDbl(dRowDeu.Item("Total"))
                                    strcNumDoc = CheckStr(dRowDeu.Item("cNumDoc").ToString)
                                End If
                            Next
                        End If

                        '' Consulta de Costas Tr�nsito y Multas Administrativas
                        dsCosTran = objActSecConBN.Consultar_DeudaCostasTransito(intCodMun, strPlaca, strCadena, strFecPag)
                        If GetNroRegistros(dsCosTran) > 0 Then
                            dblCosTran += CheckDbl(dsCosTran.Tables(0).Rows(0).Item("Total"))
                        End If
                    End If

                    ' Consulta de Deuda Tributaria
                    dsDeuTrib = objTActSecConBN.Consultar_DeudaTributaria(intCodMun, "", strcNumAEm, strFecPag)
                    If GetNroRegistros(dsDeuTrib) > 0 Then
                        For Each dRowDeu As DataRow In dsDeuTrib.Tables(0).Rows
                            If strcNumDoc <> CheckStr(dRowDeu.Item("cNumDoc").ToString) Then
                                dblDeuTri += CheckDbl(dRowDeu.Item("Total"))
                                strcNumDoc = CheckStr(dRowDeu.Item("cNumDoc").ToString)
                            End If
                        Next

                        ' Consulta de Costas Tributarias
                        dsCosTrib = objTActSecConBN.Consultar_DeudaCostasTributario(intCodMun, "", strcNumAEm, strFecPag)
                        If GetNroRegistros(dsCosTrib) > 0 Then
                            dblCosTrib = CheckDbl(dsCosTrib.Tables(0).Rows(0).Item("Total"))
                        End If
                    End If

                    ' Consulta la deuda por derechos SAT
                    dsDerSAT = objTActSecConBN.Consultar_DeudaGuardianiaGruaLibertad(intCodMun, strcNumAEm)
                    If GetNroRegistros(dsDerSAT) > 0 Then
                        If j = 0 Then
                            With dsDerSAT.Tables(0)
                                dblDerLib = CheckDbl(.Rows(0).Item("Total"))
                                dblDerGua = CheckDbl(.Rows(1).Item("Total"))
                                dblDerGru = CheckDbl(.Rows(2).Item("Total"))
                            End With
                        End If
                    End If
                Next

            Else
                ' Consulta la deuda por derechos SAT
                dsDerSAT = objTActSecConBN.Consultar_DeudaTotalInternamiento(intCodMun, strcNumBIn)
                If GetNroRegistros(dsDerSAT) > 0 Then
                    If j = 0 Then
                        With dsDerSAT.Tables(0)
                            dblDerLib = CheckDbl(.Rows(0).Item("Total"))
                            dblDerGua = CheckDbl(.Rows(1).Item("Total"))
                            dblDerGru = CheckDbl(.Rows(2).Item("Total"))
                        End With
                    End If
                End If
            End If

            ' Papeletas Prescritas
            dblPapPre = fbln_PapeletasPrescritas(vmodDepositos)

            ' Consulta de Infracciones Directas
            dblInfDir = pInfraccionesDirectas(vmodDepositos)

            dblDeuda = dblDeuTra + dblDeuTri + dblCosTrib + dblCosTran + dblCosMult + dblDerLib + dblDerGua + dblDerGru + dblPapPre + dblInfDir

            Me.lblDeuTrib.Text = fstr_FormatearMonto(dblDeuTri)
            Me.lblDeuNTrib.Text = fstr_FormatearMonto(dblDeuTra)
            Me.lblDerLib.Text = fstr_FormatearMonto(dblDerLib)
            Me.lblDerGua.Text = fstr_FormatearMonto(dblDerGua)
            Me.lblDerGru.Text = fstr_FormatearMonto(dblDerGru)
            Me.lblCosTrib.Text = fstr_FormatearMonto(dblCosTrib)
            Me.lblCosTran.Text = fstr_FormatearMonto(dblCosTran)
            'Me.lblCosAdm.Text = fstr_FormatearMonto(dblCosMult)
            Me.lblTotal.Text = fstr_FormatearMonto(dblDeuda)
            Me.lblPapPre.Text = "(" & fstr_FormatearMonto(dblPapPre) & ") " & fstr_FormatearMonto(dblTotPre)
            Me.lblInfDir.Text = fstr_FormatearMonto(dblInfDir)


            dsActSec = objTActSecConBN.Consultar_ActaSecuestroConservativo(intCodMun, _
                                                                                                  strcNumBIn)

            If GetNroRegistros(dsActSec) > 0 Then
                gvActaSecuestro.DataSource = dsActSec.Tables(0)
                gvActaSecuestro.DataBind()
                lblDetActa.Visible = True
            Else
                gvActaSecuestro.DataSource = Nothing
                gvActaSecuestro.DataBind()
                lblDetActa.Visible = False

            End If

            If hidPlacaNueva.Value <> "" Then
                strTextoMTC = GetTextoMTC()
                strPlacaMostrar = hidPlacaNueva.Value & "* " & " (antes " & hidPlacaAntigua.Value & ")"
            Else
                strTextoMTC = ""
                strPlacaMostrar = vmodDepositos.cplaca
            End If

            Dim intCodDepositoZarate As Integer = GetCodDepositoZarate()
            Dim intCodDepositoAte As Integer = GetCodDepositoAte()
            Dim intCodDepositoSantaAnita As Integer = GetCodDepositoSantaAnita()
            Dim intCodDepositoColonial As Integer = GetCodDepositoColonial()

            Dim strDireccionDepositoZarate As String = GetDireccionDepositoZarate()
            Dim strDireccionDepositoAte As String = GetDireccionDepositoAte()
            Dim strDireccionDepositoSantaAnita As String = GetDireccionDepositoSantaAnita()
            Dim strDireccionDepositoColonial As String = GetDireccionDepositoColonial()

            Dim strTelefonoDepositoZarate As String = GetTelefonoDepositoZarate()
            Dim strTelefonoDepositoAte As String = GetTelefonoDepositoAte()
            Dim strTelefonoSantaAnita As String = GetTelefonoSantaAnita()
            Dim strTelefonoColonial As String = GetTelefonoColonial()




            lblDetAct2.Text = strTextoMTC
            lblPlaca.Text = strPlacaMostrar
            lblFecInter.Text = vmodDepositos.sdfecint

            intCodDeposito = vmodDepositos.siCodDep


            lblDeposito.Text = hidDesDeposito.Value

            Select Case intCodDeposito
                Case intCodDepositoZarate
                    lblDireccion.Text = strDireccionDepositoZarate
                    lblTelefono.Text = strTelefonoDepositoZarate

                Case intCodDepositoAte
                    lblDireccion.Text = strDireccionDepositoAte
                    lblTelefono.Text = strTelefonoDepositoAte


                Case intCodDepositoSantaAnita
                    lblDireccion.Text = strDireccionDepositoSantaAnita
                    lblTelefono.Text = strTelefonoSantaAnita

                Case intCodDepositoColonial
                    lblDireccion.Text = strDireccionDepositoColonial
                    lblTelefono.Text = strTelefonoColonial

            End Select
        Catch ex As Exception
            Throw
        Finally
            If Not ds Is Nothing Then ds.Dispose()
            ds = Nothing
            If Not dsActEmb Is Nothing Then dsActEmb.Dispose()
            dsActEmb = Nothing
            If Not dsDocDeu Is Nothing Then dsDocDeu.Dispose()
            dsDocDeu = Nothing
            If Not dsDeuNTrib Is Nothing Then dsDeuNTrib.Dispose()
            dsDeuNTrib = Nothing
            If Not dsCosTran Is Nothing Then dsCosTran.Dispose()
            dsCosTran = Nothing

            If Not dsDeuTrib Is Nothing Then dsDeuTrib.Dispose()
            dsDeuTrib = Nothing
            If Not dsCosTrib Is Nothing Then dsCosTrib.Dispose()
            dsCosTrib = Nothing
            If Not dsDerSAT Is Nothing Then dsDerSAT.Dispose()
            dsDerSAT = Nothing

            If Not objTActSecConBN Is Nothing Then objTActSecConBN.Dispose()
            objTActSecConBN = Nothing
            If Not objActSecConBN Is Nothing Then objActSecConBN.Dispose()
            objActSecConBN = Nothing

            GC.Collect()
        End Try
    End Sub

    Private Function fbln_PapeletasPrescritas(ByVal vmodDepositos As mod_depositos) As Double
        Dim dsPapPre As New DataSet
        Dim dsTabDer As New DataSet
        Dim dtPapPre As New DataTable

        Dim dblPapPre As Double = 0.0
        Dim intNumPre As Integer = 0

        Try
            Using objActSecConBN As New clsActSecConBN
                dsPapPre = objActSecConBN.ConsultarDeudaNoTributariaxPlaca(vmodDepositos.sicodmun, vmodDepositos.cplaca, "2", 1) ' Actualizado 28/09/2007
            End Using

            Using dtPapPre
                If GetNroRegistros(dsPapPre) > 0 Then
                    dtPapPre = fdt_AgruparDeuda(dsPapPre.Tables(0))
                    intNumPre = dtPapPre.Rows.Count
                    For Each drDNTri As DataRow In dtPapPre.Rows
                        dblPapPre = dblPapPre + CheckDbl(drDNTri.Item("Monto").ToString)
                    Next
                End If
            End Using

            Using objTGeneralBN As New clsTGeneralBN
                dsTabDer = objTGeneralBN.ConsultarTablaDerechos("9207")
            End Using
            Using dsTabDer
                If GetNroRegistros(dsTabDer) > 0 Then
                    dblTotPre = CheckDbl(dsTabDer.Tables(0).Rows(0).Item("nValDer")) * intNumPre
                End If
            End Using

        Catch ex As Exception
            Throw
        Finally
            dsPapPre = Nothing
            dsTabDer = Nothing
            dtPapPre = Nothing
        End Try
        Return dblPapPre
    End Function

    Private Function fdt_AgruparDeuda(ByVal dtDNTrib As DataTable) As DataTable
        Dim dt As New DataTable
        Dim dr As DataRow
        Try
            dt = dtDNTrib.Clone

            For Each drDNTri As DataRow In dtDNTrib.Rows
                dr = dt.NewRow
                dr.ItemArray = drDNTri.ItemArray
                If drDNTri.Item("Sel").ToString <> "1" Then
                    dt.Rows.Add(dr)
                End If
            Next
        Catch ex As Exception
            Throw
        Finally
            dr = Nothing
        End Try
        Return dt
    End Function

    Private Function pInfraccionesDirectas(ByVal vmodDepositos As mod_depositos) As Double
        Dim objTablasBN As New clsTablasBN
        Dim dsPapDir As New DataSet
        Dim dsFalDir As New DataSet
        Dim blnPapDir As Boolean = False
        Dim dblInfDir As Double = 0.0
        Dim strCodFal As String = ""
        Try
            Using objTablasBN
                dsPapDir = objTablasBN.BuscarDeudaPapeleta(vmodDepositos.sicodmun, vmodDepositos.cpapele)
                Using dsPapDir
                    If GetNroRegistros(dsPapDir) > 0 Then
                        If CheckInt(dsPapDir.Tables(0).Rows(0).Item("siTipEdo")) = 1 Then
                            dblInfDir = CheckDbl(dsPapDir.Tables(0).Rows(0).Item("nSaldo").ToString)
                        Else
                            dblInfDir = 0.0
                        End If
                        blnPapDir = True
                    End If
                End Using
                If Not blnPapDir Then
                    strCodFal = CheckStr(vmodDepositos.ccodfal)
                    If strCodFal.Length > 0 Then
                        dsFalDir = objTablasBN.BuscarFaltas(strCodFal, vmodDepositos.sdfecint)
                        Using dsFalDir
                            If GetNroRegistros(dsFalDir) > 0 Then
                                dblInfDir = CheckDbl(dsFalDir.Tables(0).Rows(0).Item("nTotal").ToString)
                            End If
                        End Using
                    End If
                End If
            End Using
        Catch ex As Exception
            Throw
        Finally
            objTablasBN = Nothing
            dsPapDir = Nothing
            dsFalDir = Nothing
            vmodDepositos = Nothing
        End Try
        Return dblInfDir
    End Function

    Private Sub Inicio()
        Dim intUsuario As Integer = GetCodigoRegistroUsuario()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet
        Dim strUsuario As String = ""
        Dim lblusr As Label = DirectCast(Master.FindControl("lblUsuario"), Label)

        ds = oBLL.GetDatosUsuarioWeb(GetConexionSoporteWEB, intUsuario)
        If ds.Tables(0).Rows.Count > 0 Then
            With ds.Tables(0).Rows(0)
                strUsuario = CheckStr(.Item("VNOMBRE")) + " " + CheckStr(.Item("VAPEPAT"))
            End With
        End If
        If strUsuario = "" Then strUsuario = "Invitado"
        lblusr.Text = strUsuario
        ds = Nothing
        oBLL = Nothing

        Me.lblTitulo.Text = "INTERNAMIENTO DE VEHICULOS"
        lblMensaje.Text = ""
        lblMensajeVacio.Text = ""
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
        Ocultar()
    End Sub

#End Region

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Inicio()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
        End If
    End Sub

    Protected Sub ibtnRefresh_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs)
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
    End Sub

    Protected Sub CaptchaContinue_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CaptchaContinue.Click
        GestionarConsulta()
        Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)

    End Sub

    '''<summary>M�todo para validar el c�digo captcha.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Function fbln_ValidarCaptha() As Boolean
        Dim blnRespuesta As Boolean
        If Session("CaptchaImageText") IsNot Nothing AndAlso txtCaptcha.Text.ToLower() = Session("CaptchaImageText").ToString().ToLower() Then
            blnRespuesta = True
        Else
            Session("CaptchaImageText") = CaptchaDLL.CaptchaImage.GenerateRandomCode(CaptchaType.AlphaNumeric, intCaptcha)
        End If
        Return blnRespuesta
    End Function

    '''<summary>M�todo para ejecutar las consultas en base al tipo de consulta.</summary>
    '''<remarks><list type="bullet">
    '''<item><CreadoPor>Lucar Capristano Carrillo</CreadoPor></item>
    '''<item><FecCrea>15/09/2015</FecCrea></item></list>
    '''<list type="bullet">
    '''<item><FecActu></FecActu></item>
    '''<item><Resp></Resp></item>
    '''<item><Mot></Mot></item></list></remarks>
    Private Sub GestionarConsulta()
        If (Me.txtPlaca.Text.Length > 4) Then
            If fbln_ValidarCaptha() Then
                pBuscarDatosInternamiento()
                Me.lblMensajeCapcha.Text = Nothing
            Else
                Me.lblMensajeCapcha.Text = Resources.Parametros.strMsjAlertaCapcha
            End If
        Else
            Me.lblMensajeCapcha.Text = Resources.Parametros.strMsjPlacaIncorrecta
        End If
    End Sub
End Class
