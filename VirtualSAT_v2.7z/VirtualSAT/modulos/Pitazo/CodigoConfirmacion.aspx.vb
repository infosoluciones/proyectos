﻿Option Explicit On
Option Strict On
Imports FuncionesWeb
Imports System.Data
Imports SAT.HomeSiteBLL.ConsultasWeb
Imports SAT.Funciones.Validaciones
Partial Class modulos_pitazo_CodigoConfirmacion
    Inherits System.Web.UI.Page
#Region " Declaraciones "
    Private intCodUsuario As Integer = 0
    Private strCodigo As String = ""
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim dsUsuario As DataSet
        Dim strMensaje As String = ""
        Dim intCodUsuario As Integer = 0
        Dim strApePat, strApeMat, strNombre, strCelular, strCadenaEnvio, strEmail As String
        Dim bolEstadoCelular As Boolean = False
        Dim strServer As String = ""
        Dim strRuta As String = ""
        Dim strRutaReconfirmacion As String = ""
        Dim strCodigoEncriptado As String = ""

        If Not Page.IsPostBack Then

            strCodigo = GetURL("codigo")
            strCodigoEncriptado = SetURL("codigo", strCodigo)
            intCodUsuario = Convert.ToInt32(strCodigo)

            If intCodUsuario > 0 Then
                dsUsuario = oBLL.BuscarUsuarioWEBxCodigo(GetConexionSoporteWEB, intCodUsuario)
                If Not dsUsuario Is Nothing Then
                    If dsUsuario.Tables(0).Rows.Count > 0 Then
                        intCodUsuario = CheckInt(dsUsuario.Tables(0).Rows(0)("NCODUSU"))

                        strApePat = CheckStr(dsUsuario.Tables(0).Rows(0)("VAPEPAT"))
                        strApeMat = CheckStr(dsUsuario.Tables(0).Rows(0)("VAPEMAT"))
                        strNombre = CheckStr(dsUsuario.Tables(0).Rows(0)("VNOMBRE"))
                        strCelular = CheckStr(dsUsuario.Tables(0).Rows(0)("VCELULA"))
                        strEmail = CheckStr(dsUsuario.Tables(0).Rows(0)("VEMAIL"))

                        strCadenaEnvio = intCodUsuario.ToString
                        strRutaReconfirmacion = "CodigoReconfirmacion.aspx?" + strCodigoEncriptado

                        Me.lblCelular.Text = strCelular
                        Me.hdnHref.Value = strRutaReconfirmacion

                        If IsNumeric(dsUsuario.Tables(0).Rows(0).Item("bConfirmacionSMS")) Then
                            bolEstadoCelular = CType(dsUsuario.Tables(0).Rows(0).Item("bConfirmacionSMS"), Boolean)
                        End If

                        If Not bolEstadoCelular And strCelular <> "" Then
                            EnviarSMSConfirmacion(intCodUsuario, strCelular)
                        End If


                        If Not String.IsNullOrEmpty(strEmail) Then
                            EnviarCorreo(strEmail, strApePat, strApeMat, strNombre, strCodigoEncriptado)
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    Protected Sub btnConfirmar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmar.Click
        Dim ds As New DataSet
        Dim strMensaje As String = ""
        Dim strScript As String = ""
        Dim blnConfirmado As Boolean = False
        Dim strRuta As String = ""


        strCodigo = GetURL("codigo")

        intCodUsuario = Convert.ToInt32(strCodigo)
        Try
            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                ds = oBLL.ConfirmarServicioSMS(GetConexionSoporteWEB, intCodUsuario, Me.txtCodigo.Text, GetIPTerminal)
            End Using

            If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then
                blnConfirmado = SAT.Base.Lib.Datos.CheckBln(ds.Tables(0).Rows(0).Item("bConfirmacionSMS"))
                'End If
                If blnConfirmado Then

                    strRuta = "FinRegistroCodigo.aspx?" + SetURL("codigo", strCodigo)
                    Response.Redirect(strRuta, False)
                Else
                    strMensaje = ""
                    strMensaje += "No se puede realizar la subscripción, el código de cofirmación es incorrecto."
                    strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "Confirmación", strScript)
                End If
            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
        End Try
    End Sub
    Private Sub EnviarSMSConfirmacion(ByVal vintCodUsu As Integer, ByVal vstrCelular As String)
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim ds As New DataSet
        Dim blnEnviado As Boolean = False
        Dim strMensaje As String = ""
        Dim respuesta As String = ""
        Try
            ds = oBLL.RegistrarServicioSMS(GetConexionSoporteWEB, vintCodUsu, vstrCelular, GetIPTerminal)
            If ds.Tables(0).Rows.Count > 0 Then
                strMensaje = "SAT de Lima." & Chr(10)
                strMensaje += "Su codigo de confirmacion al servicio Pitazo Preventivo e Informativo por SMS es: " & CheckStr(ds.Tables(0).Rows(0).Item("cPasswordConfirmacion"))

                Using oSMS As New SAT.SIAT.COM.BLL.Libreria.NX.Sms_Ip
                    respuesta = oSMS.EnviarMensaje(vstrCelular, strMensaje)
                End Using

            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
            oBLL = Nothing
        End Try
    End Sub
    Protected Sub btnCancelar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Response.Redirect("Default.aspx")
    End Sub

    Protected Sub EnviarCorreo(ByVal strEmail As String, ByVal strApePat As String, ByVal strApeMat As String, ByVal strNombre As String, ByVal strCodigoEncriptado As String)
        Dim strMensaje As String = ""
        Dim strServer As String = ""

        'Enviar constancia de registro
        strMensaje = ""
        strMensaje += "Gracias por registrarse como usuario del servicio Pit@zo preventivo e informativo. " & Chr(13) & Chr(13)

       
 	If Request.ServerVariables("SERVER_NAME") = "webiisprod01" Then
                         strServer = "https://www.sat.gob.pe/VirtualSat/modulos/Pitazo/FinRegistroCorreo.aspx?" + strCodigoEncriptado
                    ElseIf Request.ServerVariables("SERVER_NAME") = "webiispre01" Then
                         strServer = "http://webiispre01/VirtualSat/modulos/Pitazo/FinRegistroCorreo.aspx?" + strCodigoEncriptado
                    ElseIf (Request.ServerVariables("SERVER_NAME") = "webiis_des01" Or Request.ServerVariables("SERVER_NAME") = "172.29.55.188") Then
                           strServer = "http://webiis_des01/VirtualSat/modulos/Pitazo/FinRegistroCorreo.aspx?" + strCodigoEncriptado
                    Else
                         strServer = "https://www.sat.gob.pe/VirtualSat/modulos/Pitazo/FinRegistroCorreo.aspx?" + strCodigoEncriptado
                    End If




        strMensaje += "A fin de concluir con el proceso de registro, visite el siguiente enlace " & Chr(13) & Chr(13)
        strMensaje += "(Si tienes problemas con el codigo de seguridad, por favor copia directamente el link en tu navegador y recarga la pagina) : " & Chr(13)
        'strMensaje += strServer
        'strMensaje += "<a href=" & Chr(34) & strServer & Chr(34) + ">" & strServer & "</a>"
        strMensaje += Chr(32) & strServer & Chr(32) '& Chr(13)

        strMensaje += "  Esta es la informacion de la cuenta:" & Chr(13) & Chr(13)
        strMensaje += "Nombre  : " & Trim(UCase(strNombre)) & " " & Trim(UCase(strApePat)) & " " & Trim(UCase(strApeMat)) & " " & Chr(13) & Chr(13)
        strMensaje += "Usuario : " & strEmail & Chr(13) & Chr(13)
        strMensaje += "Atentamente," & Chr(13) & Chr(13)
        strMensaje += "Servicio de Administracion Tributaria" & Chr(13) & Chr(13)

        strMensaje += "PD: Las tildes y enies se han omitido para evitar problemas de compatibilidad entre los software de correo electronico" & Chr(13) & Chr(13)

        If strEmail <> "" Then
            Using oBLLMail As New SAT.SIAT.COM.BLL.Libreria.NX.Correo
                oBLLMail.EnvioEmail("REGISTRO - SAT <satvirtual@sat.gob.pe>", strEmail, "SAT Confirmacion de registro", strMensaje)
            End Using
        End If
    End Sub

End Class
