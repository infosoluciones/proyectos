﻿Option Explicit On
Option Strict On
Imports SAT
Imports FuncionesWeb
Imports System.Data
Imports SAT.HomeSiteBLL.ConsultasWeb
Imports SAT.Funciones.Validaciones
Partial Class modulos_pitazo_PlacasContacto
    Inherits System.Web.UI.Page
#Region " Declaraciones "
    Private intCodigoUsuario As Integer = 0
    Private intCodUsuarioCel As Integer = 0
    Private strNumeroDocumento As String = ""




#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim dsUsuario As DataSet
        Dim strURL As String = ""
        Dim strCodigo As String = ""
        Dim strEmail As String = ""
        Dim strCelular As String = ""

   


        strCodigo = GetURL("codigo")
        intCodigoUsuario = Convert.ToInt32(strCodigo)

        If strCodigo.Length > 0 Then
            Try
                dsUsuario = oBLL.BuscarUsuarioWEBMultiple(GetConexionSoporteWEB, intCodigoUsuario, "", "", "")
                If SAT.Base.Lib.Datos.RowCount(dsUsuario) > 0 Then
                    strEmail = SAT.Base.Lib.Datos.CheckStr(dsUsuario.Tables(0).Rows(0)("vEmail"))
                    strCelular = SAT.Base.Lib.Datos.CheckStr(dsUsuario.Tables(0).Rows(0)("vCelula"))
                    strNumeroDocumento = SAT.Base.Lib.Datos.CheckStr(dsUsuario.Tables(0).Rows(0)("vNroDoc"))
                    Me.lblCelular.Text = EnmascaraCelular(strCelular)
                    Me.lblEmail.Text = EnmascaraEmail(strEmail)
                    If Not Me.Page.IsPostBack Then
                        MostrarPlacas(strNumeroDocumento)
                        MostrarDatos(strNumeroDocumento)
                    End If
                Else
                    strCodigo = ""
                    strURL = "/modulos/Pitazo/Default.aspx"
                    Response.Redirect(strURL)
                End If
            Catch ex As Exception
                SAT.Base.Web.App.Errores.Registrar(Me, ex)
            Finally
                dsUsuario = Nothing
            End Try
        Else
            strURL = "/modulos/Pitazo/Default.aspx"
            Response.Redirect(strURL)
        End If





    End Sub
#Region "Placas"
    Protected Sub btnAgregar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAgregar.Click
        AgregarPlaca()
    End Sub
    Protected Sub grdMisPlacas_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdMisPlacas.PageIndexChanging
        Me.grdMisPlacas.PageIndex = e.NewPageIndex
        grdMisPlacas.PageIndex = e.NewPageIndex
        MostrarPlacas(strNumeroDocumento)
    End Sub
    Protected Sub grdMisPlacas_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdMisPlacas.RowDataBound
        On Error Resume Next
        If e.Row.RowType <> DataControlRowType.DataRow Then Return
    End Sub
    Protected Sub grdMisPlacas_RowDeleting(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewDeleteEventArgs) Handles grdMisPlacas.RowDeleting




        If e.RowIndex > -1 Then
            Dim strPlaca As String = ""
            Dim index As Integer
            Dim nCodUsu As Integer
            index = e.RowIndex
            nCodUsu = Convert.ToInt32(Me.grdMisPlacas.DataKeys(index).Values(0))
            strPlaca = Me.grdMisPlacas.DataKeys(index).Values(1).ToString().Trim()

            EliminarPlaca(nCodUsu, strPlaca)



        End If



    End Sub
    Private Sub MostrarPlacas(ByVal strNumDocumento As String)
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim ds As DataSet
        Dim intItem As Integer
        Dim strMensaje As String = ""
        Dim strScript As String = ""

        Try

            ds = oBLL.MostrarPlacasUsuarioDocumento(GetConexionSoporteWEB, strNumDocumento)
            For intItem = 0 To ds.Tables(0).Rows.Count - 1
                ds.Tables(0).Rows(intItem)("NFILA") = intItem + 1
            Next

            If ds.Tables.Count > 0 Then
                Me.grdMisPlacas.DataSource = ds.Tables(0)
                Me.grdMisPlacas.DataBind()
                Me.lblNumPlacas.Text = "Se encontraron <b>" + ds.Tables(0).Rows.Count.ToString + "</b> placa(s) registrada(s)."

            End If
        Catch ex As Exception
            strMensaje = ""
            strMensaje += "Error al cargar data "
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validación", strScript)
        Finally
            oBLL = Nothing
            ds = Nothing
        End Try
    End Sub
    Private Sub AgregarPlaca()
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim ds As DataSet
        Dim strMensaje As String = ""
        Dim strScript As String = ""

        Try
            Dim strPlaca As String = Nothing
            strPlaca = Convert.ToString(Me.hdnfldtxtPlaca.Value)
            strPlaca = UCase(strPlaca)
            strPlaca = ValidaCadena(strPlaca)
            If strPlaca.Length > 4 Then
                ds = oBLL.RegistrarPlaca(GetConexionSoporteWEB, intCodigoUsuario, strPlaca)
                Me.hdnfldtxtEmail.Value = ""
                Me.hdnfldtxtCelular.Value = ""
                Me.hdnfldtxtPlaca.Value = ""
                Me.hdnfldtxtPlacaConfirmacion.Value = ""
                MostrarPlacas(strNumeroDocumento)
            Else
                Me.hdnfldtxtEmail.Value = ""
                Me.hdnfldtxtCelular.Value = ""
                Me.hdnfldtxtPlaca.Value = ""
                Me.hdnfldtxtPlacaConfirmacion.Value = ""
                strMensaje = ""
                strMensaje += "Placa incorrecta "
                strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validación", strScript)
            End If

        Catch ex As Exception
            Me.hdnfldtxtEmail.Value = ""
            Me.hdnfldtxtCelular.Value = ""
            Me.hdnfldtxtPlaca.Value = ""
            Me.hdnfldtxtPlacaConfirmacion.Value = ""
            strMensaje = ""
            strMensaje += "Error  al Registrar Placa"
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validación", strScript)
        Finally
            oBLL = Nothing
        End Try
    End Sub
    Private Sub EliminarPlaca(ByVal nCodUsu As Integer, ByVal strPlaca As String)
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim ds As DataSet
        Dim strMensaje As String = ""
        Dim strScript As String = ""

        Try



            ds = oBLL.EliminarPlacaUsuario(GetConexionSoporteWEB, nCodUsu, strPlaca)
            MostrarPlacas(strNumeroDocumento)

        Catch ex As Exception
            strMensaje = ""
            strMensaje += "Error: " & ex.Message
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validación", strScript)
        Finally
            oBLL = Nothing
        End Try
    End Sub
#End Region
#Region "Datos Contacto"
    Protected Sub btnAgregarDatos_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAgregarDatos.Click
        If (IsPostBack) Then
            Dim strMensaje As String = ""
        Else
            Dim strMensaje As String = ""
        End If
        If (IsCallback) Then
            Dim strMensaje As String = ""
        Else
            Dim strMensaje As String = ""
        End If
        AgregarDatos()
    End Sub
    Protected Sub grdMisDatos_PageIndexChanging(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewPageEventArgs) Handles grdMisDatos.PageIndexChanging
        Me.grdMisDatos.PageIndex = e.NewPageIndex
        grdMisDatos.PageIndex = e.NewPageIndex
        MostrarDatos(strNumeroDocumento)
    End Sub
    Protected Sub grdMisDatos_RowDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.GridViewRowEventArgs) Handles grdMisDatos.RowDataBound
        On Error Resume Next
        If e.Row.RowType <> DataControlRowType.DataRow Then Return
    End Sub
    Private Sub MostrarDatos(ByVal strNumDoc As String)
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim ds As DataSet
        Dim intItem As Integer
        Dim strMensaje As String = ""
        Dim strScript As String = ""
        Dim strEmail As String = ""
        Dim strCelular As String = ""
        Try

            ds = oBLL.BuscarUsuarioWEBDatosMultiple(GetConexionSoporteWEB, 0, "", "", strNumDoc)
            For intItem = 0 To ds.Tables(0).Rows.Count - 1
                ds.Tables(0).Rows(intItem)("NFILA") = intItem + 1
                strEmail = ds.Tables(0).Rows(intItem)("VEMAIL").ToString()
                If Not strEmail = "" Then strEmail = EnmascaraEmail(strEmail)
                strCelular = ds.Tables(0).Rows(intItem)("VCELULA").ToString()
                If Not strCelular = "" Then strCelular = EnmascaraCelular(strCelular)
                ds.Tables(0).Rows(intItem)("VEMAIL") = strEmail
                ds.Tables(0).Rows(intItem)("VCELULA") = strCelular
            Next

            If ds.Tables.Count > 0 Then
                Me.grdMisDatos.DataSource = ds.Tables(0)
                Me.grdMisDatos.DataBind()
            End If
        Catch ex As Exception
            strMensaje = ""
            strMensaje += "Error al cargar data "
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validación", strScript)
        Finally
            oBLL = Nothing
            ds = Nothing
        End Try
    End Sub
    Private Sub AgregarDatos()
        Dim strEmail As String = Convert.ToString(Me.hdnfldtxtEmail.Value)
        Dim strCelular As String = Convert.ToString(Me.hdnfldtxtCelular.Value)
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim strMensaje As String = ""
        Dim strScript As String = ""

        Try
            If (strCelular <> "" And strEmail <> "") Then
                AgregarCelular()
                AgregarCorreo()
            ElseIf (strCelular <> "" And strEmail = "") Then
                AgregarCelular()
            ElseIf (strCelular = "" And strEmail <> "") Then
                AgregarCorreo()
            End If
            Me.hdnfldtxtEmail.Value = ""
            Me.hdnfldtxtCelular.Value = ""
            Me.hdnfldtxtPlaca.Value = ""
            Me.hdnfldtxtPlacaConfirmacion.Value = ""
            MostrarDatos(strNumeroDocumento)
        Catch ex As Exception
            strMensaje = ""
            strMensaje += "Error al Registrar Datos de Contacto"
            strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
            Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validación", strScript)
            Page.ClientScript.RegisterStartupScript(GetType(String), "ClientScript", "LimpiarControles()", True)
        Finally
            oBLL = Nothing
        End Try
    End Sub
    Private Sub AgregarCorreo()
        Dim dsUsuario As New DataSet
        Dim dsEmail As New DataSet
        Dim strEmail As String = Convert.ToString(Me.hdnfldtxtEmail.Value)
        Dim strMensaje As String = ""
        Dim strMensajeCel As String = ""
        Dim strScript As String = ""
        Dim blnEnviado As Boolean = False
        Dim strServer As String = ""
        Dim strCodUsuario As String = ""
        Dim intCodUsuario As Integer = 0
        Dim strEstadoUsuario As String = ""
        Dim blnEstadoCelular As Boolean = False

        Try
            ' Realiza la búsqueda del email

            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                dsUsuario = oBLL.BuscarUsuarioWEBMultiple(GetConexionSoporteWEB, 0, strEmail, "", strNumeroDocumento)
            End Using

            If SAT.Base.Lib.Datos.RowCount(dsUsuario) > 0 Then
                strMensaje = ""
                strMensaje += "Correo electrónico ya registrado"
                strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validación", strScript)
            Else
                'Si el email no se encuentra registrado
                Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                    If intCodUsuarioCel > 0 Then

                        dsEmail = oBLL.RegistrarEmail(GetConexionSoporteWEB, intCodUsuarioCel, strEmail)
                    Else
                        dsEmail = oBLL.RegistrarSuscripcionEmail(GetConexionSoporteWEB, intCodigoUsuario, strEmail)
                    End If
                End Using

                If SAT.Base.Lib.Datos.RowCount(dsEmail) > 0 Then

                    ' Mensaje para la alerta
                    strMensaje = ""
                    strMensaje += "Se registró la información correctamente"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "Confirmación", strScript)
                End If
            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (dsUsuario Is Nothing) Then dsUsuario.Dispose()
            dsUsuario = Nothing
        End Try

    End Sub
    Private Sub AgregarCelular()
        Dim strCelular As String = Convert.ToString(Me.hdnfldtxtCelular.Value)
        Dim dsUsuario As New DataSet
        Dim dsCelular As New DataSet
        Dim strMensaje As String = ""
        Dim strMensajeCel As String = ""
        Dim strScript As String = ""
        Dim blnEnviado As Boolean = False
        Dim respuesta As String = ""
        Dim strFecEnv As String = ""
        Dim strCodUsuario As String = ""
        Dim intCodUsuario As Integer = 0
        Dim strClaveCelular As String = ""
        Dim strEstadoUsuario As String = ""
        Dim blnEstadoCelular As Boolean = False

        Try
            ' Realiza la busqueda del número de celular
            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
                dsUsuario = oBLL.BuscarUsuarioWEBDatosMultiple(GetConexionSoporteWEB, 0, "", strCelular, strNumeroDocumento)
            End Using
            ' Verifica que el número de celular se encuentre registrado
            If SAT.Base.Lib.Datos.RowCount(dsUsuario) > 0 Then
                strMensaje = ""
                strMensaje += "Celular ya se encuentra registrado"
                strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                Page.ClientScript.RegisterStartupScript(Me.GetType(), "Validación", strScript)
            Else 'Si el celular no se encuentra registrado
                Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb

                    dsCelular = oBLL.RegistrarSuscripcionServicioSMS(GetConexionSoporteWEB, intCodigoUsuario, Convert.ToString(Me.hdnfldtxtCelular.Value), GetIPTerminal)
                
                End Using

                If SAT.Base.Lib.Datos.RowCount(dsCelular) > 0 Then
                    With dsCelular.Tables(0).Rows(0)
                        intCodUsuarioCel = CheckInt(.Item("nCodUsu"))
                    End With
                    strMensaje = ""
                    strMensaje += "Se registró la información correctamente"
                    strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "Confirmación", strScript)
                End If
            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (dsUsuario Is Nothing) Then dsUsuario.Dispose()
            dsUsuario = Nothing
            If Not (dsCelular Is Nothing) Then dsCelular.Dispose()
            dsCelular = Nothing
        End Try

    End Sub
#End Region
#Region "Funciones"
    Private Function EnmascaraCelular(ByVal vstrCelular As String) As String
        Dim strMascara As String = ""

        strMascara = Left(vstrCelular, 4) & "*****"

        Return strMascara

    End Function
    Private Function EnmascaraEmail(ByVal vstrEmail As String) As String
        Dim strMascara As String = ""
        Dim intCaracter As Integer = 0

        intCaracter = vstrEmail.IndexOf("@")
        If intCaracter = -1 Then
            strMascara = ""
        Else
            strMascara = Left(vstrEmail, intCaracter + 1) & "********"
        End If

        Return strMascara
    End Function
    Public Function ValidaEmail(ByVal vstrCadena As String) As Boolean
        Dim SeccionesEMail As String() = vstrCadena.Split(CChar("@"))

        If vstrCadena.Trim.Length = 0 Then
            Return True
        End If

        'Valida Expresiones Regulares
        If Not Regex.IsMatch(vstrCadena, "^([\w-]+\.)*?[\w-]+@[\w-]+\.([\w-]+\.)*?[\w]+$") Then
            Return False
        End If

        If vstrCadena.Trim.Length = 0 Then
            Return True
        End If

        'Como primera regla un correo electronico debe contener la @
        If Not vstrCadena.Contains("@") Then
            Return False
        End If

        'Dividimos la cadena en secciones, obviamente estas deben ser 2
        'el usuario y el host, utilizamos como separador la @
        'Ahora verificamos que evidentemente solo sean 2 secciones, ya que 
        'en caso contrario eso significa que hay mas de una @ y eso es incorrecto
        If SeccionesEMail.Length <> 2 Then
            Return False
        End If

        'Ahora verificamos que la segunda seccion de la cadena de correo contenga
        'al menos un punto, ya que la seccion del dominio debe contener el punto
        'Podemos establecer un tamaño minimo para el dominio en este caso le puse 3
        If Not SeccionesEMail(1).Contains(".") Or Not SeccionesEMail(1).Length >= 3 Then
            Return False
        End If


        Return True

    End Function

#End Region

End Class

