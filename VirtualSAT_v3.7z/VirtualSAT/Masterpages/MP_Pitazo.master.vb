﻿
Partial Class MasterPages_MP_Pitazo
    Inherits System.Web.UI.MasterPage
End Class

