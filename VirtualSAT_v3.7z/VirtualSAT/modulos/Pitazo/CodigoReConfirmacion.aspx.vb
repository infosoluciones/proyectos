﻿Option Explicit On
Option Strict On
Imports FuncionesWeb
Imports System.Data
Imports SAT.HomeSiteBLL.ConsultasWeb
Imports SAT.Funciones.Validaciones
Partial Class modulos_pitazo_CodigoReConfirmacion
    Inherits System.Web.UI.Page
#Region " Declaraciones "
    Private intCodUsuario As Integer = 0
    Private strCodigo As String = ""
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
            Dim dsUsuario As DataSet
            Dim strMensaje As String = ""
            Dim intCodUsuario As Integer = 0
            Dim strApePat, strApeMat, strNombre, strCelular As String
            Dim bolEstadoCelular As Boolean = False
            Dim strRuta As String = ""
            Dim strRutaReconfirmacion As String = ""


            strCodigo = GetURL("codigo")
            intCodUsuario = Convert.ToInt32(strCodigo)

            If intCodUsuario > 0 Then
                dsUsuario = oBLL.BuscarUsuarioWEBxCodigo(GetConexionSoporteWEB, intCodUsuario)
                If Not dsUsuario Is Nothing Then
                    If dsUsuario.Tables(0).Rows.Count > 0 Then
                        intCodUsuario = CheckInt(dsUsuario.Tables(0).Rows(0)("NCODUSU"))
                        strApePat = CheckStr(dsUsuario.Tables(0).Rows(0)("VAPEPAT"))
                        strApeMat = CheckStr(dsUsuario.Tables(0).Rows(0)("VAPEMAT"))
                        strNombre = CheckStr(dsUsuario.Tables(0).Rows(0)("VNOMBRE"))
                        strCelular = CheckStr(dsUsuario.Tables(0).Rows(0)("VCELULA"))
                        strRutaReconfirmacion = "CodigoReconfirmacion.aspx?" + SetURL("codigo", strCodigo)

                        Me.lblCelular.Text = strCelular
                        Me.hdnHref.Value = strRutaReconfirmacion

                        If IsNumeric(dsUsuario.Tables(0).Rows(0).Item("bConfirmacionSMS")) Then
                            bolEstadoCelular = CType(dsUsuario.Tables(0).Rows(0).Item("bConfirmacionSMS"), Boolean)
                        End If

                        If Not bolEstadoCelular And strCelular <> "" Then
                            EnviarSMSConfirmacion(intCodUsuario, strCelular)
                        End If
                    End If
                End If
            End If
        End If
    End Sub
    Protected Sub btnConfirmar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnConfirmar.Click
        Dim ds As New DataSet
        Dim strMensaje As String = ""
        Dim strScript As String = ""
        Dim blnConfirmado As Boolean = False
        Dim strRuta As String = ""


        strCodigo = GetURL("codigo")
        intCodUsuario = Convert.ToInt32(strCodigo)
        Try


            Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb

                ds = oBLL.ConfirmarServicioSMS(GetConexionSoporteWEB, intCodUsuario, Me.txtCodigo.Text, GetIPTerminal)

            End Using

            If SAT.Base.Lib.Datos.RowCount(ds) > 0 Then
                blnConfirmado = SAT.Base.Lib.Datos.CheckBln(ds.Tables(0).Rows(0).Item("bConfirmacionSMS"))
                'End If
                If blnConfirmado Then

                    strRuta = "FinRegistroCodigo.aspx?" + SetURL("codigo", strCodigo)
                    Response.Redirect(strRuta, False)
                Else
                    strMensaje = ""
                    strMensaje += "No se puede realizar la subscripción, el código de cofirmación es incorrecto."
                    strScript = "<script language='javascript'> alert('" & strMensaje & "'); </script>"
                    Page.ClientScript.RegisterStartupScript(Me.GetType(), "Confirmación", strScript)
                End If
            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
        End Try
    End Sub
    Private Sub EnviarSMSConfirmacion(ByVal vintCodUsu As Integer, ByVal vstrCelular As String)
        Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
        Dim ds As New DataSet
        Dim blnEnviado As Boolean = False
        Dim strMensaje As String = ""
        Dim respuesta As String = ""
        Try

            ds = oBLL.RegistrarServicioSMS(GetConexionSoporteWEB, vintCodUsu, vstrCelular, GetIPTerminal)

            If ds.Tables(0).Rows.Count > 0 Then
                strMensaje = "SAT de Lima." & Chr(10)
                strMensaje += "Su codigo de confirmacion al servicio Pitazo Preventivo e Informativo por SMS es: " & CheckStr(ds.Tables(0).Rows(0).Item("cPasswordConfirmacion"))


                Using oSMS As New SAT.SIAT.COM.BLL.Libreria.NX.Sms_Ip
                    respuesta = oSMS.EnviarMensaje(vstrCelular, strMensaje)
                End Using

            End If
        Catch ex As Exception
            SAT.Base.Web.App.Errores.Registrar(Me, ex)
        Finally
            If Not (ds Is Nothing) Then ds.Dispose()
            ds = Nothing
            oBLL = Nothing
        End Try
    End Sub
    Protected Sub btnCancelar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnCancelar.Click
        Response.Redirect("Default.aspx")
    End Sub
End Class
