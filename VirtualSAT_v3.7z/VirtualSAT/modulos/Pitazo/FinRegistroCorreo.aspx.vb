﻿Option Explicit On
Option Strict On
Imports FuncionesWeb
Imports System.Data
Imports SAT.HomeSiteBLL.ConsultasWeb
Imports SAT.Funciones.Validaciones
Partial Class modulos_pitazo_FinRegistroCorreo
    Inherits System.Web.UI.Page
#Region " Declaraciones "
    Private intCodUsuario As Integer = 0
    Private strCodigo As String = ""
#End Region
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim oBLL As New SAT.HomeSiteBLL.ConsultasWeb
            Dim dsUsuario As DataSet
            Dim strMensaje As String = ""
            Dim intCodUsuario As Integer = 0
            Dim strApePat, strApeMat, strNombre, strCelular, strEmail, strNombreCompleto As String
            Dim bolEstadoCelular As Boolean = False
            Dim strServer As String = ""


            strCodigo = GetURL("codigo")
            intCodUsuario = Convert.ToInt32(val(strCodigo))

            If intCodUsuario > 0 Then
                dsUsuario = oBLL.ActualizarConfirmacionRegistro(GetConexionSoporteWEB, intCodUsuario, GetIPTerminal)
                If Not dsUsuario Is Nothing Then
                    If dsUsuario.Tables(0).Rows.Count > 0 Then
                        intCodUsuario = CheckInt(dsUsuario.Tables(0).Rows(0)("NCODUSU"))
                        strApePat = CheckStr(dsUsuario.Tables(0).Rows(0)("VAPEPAT"))
                        strApeMat = CheckStr(dsUsuario.Tables(0).Rows(0)("VAPEMAT"))
                        strNombre = CheckStr(dsUsuario.Tables(0).Rows(0)("VNOMBRE"))
                        strCelular = CheckStr(dsUsuario.Tables(0).Rows(0)("VCELULA"))
                        strEmail = CheckStr(dsUsuario.Tables(0).Rows(0)("VEMAIL"))
                        strNombreCompleto = strNombre & " " & strApePat & " " & strApeMat

                        Me.lblNombre.Text = strNombreCompleto
                        Me.lblNombreCompleto.Text = strNombreCompleto
                        Me.lblEmail.Text = strEmail
                        Me.LabelCelular.Text = strCelular
                    End If
                End If
            End If
        End If
    End Sub
    Protected Sub btnAceptar_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnAceptar.Click
        Dim strRuta As String = ""
        strRuta = "Default.aspx"
        Response.Redirect(strRuta, False)
    End Sub
End Class
