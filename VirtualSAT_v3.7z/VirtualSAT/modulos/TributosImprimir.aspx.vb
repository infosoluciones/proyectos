Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports SAT.Funciones.Validaciones

Partial Class modulos_TributosImprimir
   Inherits System.Web.UI.Page

   Private mstrSession As String
   Private mstrConcepto As String
   Private mstrAnio As String
   Private mstrEstado As String
   Private mstrCodUsu As String
   Private mstrTributo As String
   Private mstrReferencia As String
   Private mintTotal As Integer = 0
   Private mdblTotalDeuda As Double = 0
   Private mdblTotalPagado As Double = 0
   Private mdtDeuda As DataTable

   Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
      If Not IsPostBack Then
         pInicio()
         RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
      End If
   End Sub

   Private Sub pInicio()
      Dim strFileTemp As String = ""
      Dim dsDeuda As DataSet

      mstrSession = Request("ses")
      mstrConcepto = Request("con")
      mstrAnio = Request("ani")
      mstrEstado = Request("est")
      mstrCodUsu = Request("usu")

      Me.lblAdministrado.Text = CheckStr(Session("administrado"))

      strFileTemp = GetRutaFisica("temp/") + Date.Today.ToString("ddMMyyyy") + _
                     "_" + mstrSession.ToString + _
                     "_" + mstrConcepto.ToString + _
                     "_" + mstrAnio.ToString + _
                     "_" + mstrEstado.ToString + _
                     "_" + mstrCodUsu.ToString

      dsDeuda = New DataSet
      If IO.File.Exists(strFileTemp + ".xml") Then
         'desde file salvado
         dsDeuda.ReadXml(strFileTemp + ".xml")
         mdtDeuda = dsDeuda.Tables(0)
         'buscar deuda
         Dim dvwDetalle As DataView = New DataView(mdtDeuda)
         dvwDetalle.Sort = "[a�o],Tributo,Referencia"
         dvwDetalle.RowFilter = "PERIODO > 0"
         Me.dlsEstadoCuenta.DataSource = dvwDetalle
         Me.dlsEstadoCuenta.DataBind()
      End If

      'mostrar totales
      Me.lblDeudaTotal.Text = mdblTotalDeuda.ToString("#0.00")
      Me.lblTotalPagado.Text = mdblTotalPagado.ToString("#0.00")
      Me.lblCantidadTotal.Text = mintTotal.ToString

      dsDeuda.Dispose()
      dsDeuda = Nothing

        pMostrarPie()

   End Sub

   Private Sub dlsEstadoCuenta_ItemDataBound(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DataListItemEventArgs) Handles dlsEstadoCuenta.ItemDataBound
      If e.Item.ItemType = ListItemType.Item Or e.Item.ItemType = ListItemType.AlternatingItem Then
         Dim strAnno, strTributo, strRef As String
         Dim strPeriodo As String = ""

         strAnno = CType(e.Item.FindControl("lblAnno"), Label).Text
         strTributo = CType(e.Item.FindControl("lblTributo"), Label).Text
         strRef = CType(e.Item.FindControl("lblRef"), Label).Text

         If strAnno <> mstrAnio Or strTributo <> mstrTributo Or strRef <> mstrReferencia Then
            Dim dvwDet As New DataView(mdtDeuda)
            Dim ucDetalle As Control = LoadControl("../controles/ucDetalleEstadoCuentaNuevo.ascx")
            Dim dblDeuda, dblPagado As Double
            dblDeuda = 0
            dblPagado = 0
            dvwDet.RowFilter = "[a�o]='" + strAnno + "' and tributo='" + strTributo + "' and referencia='" + strRef + "'"
            CType(ucDetalle.FindControl("dgrDetalle"), DataGrid).DataSource = dvwDet
            CType(ucDetalle.FindControl("dgrDetalle"), DataGrid).DataBind()
            CType(e.Item.FindControl("divDetalle"), Panel).Controls.Add(ucDetalle)
            mstrAnio = strAnno
            mstrTributo = strTributo
            mstrReferencia = strRef
            pCalcularTotales(dvwDet, dblPagado, dblDeuda, mintTotal)
            mdblTotalDeuda += dblDeuda
            mdblTotalPagado += dblPagado
            CType(e.Item.FindControl("lblDeuda"), Label).Text = "SUB TOTAL DE DEUDA: " + dblDeuda.ToString("#0.00")
         Else
            e.Item.Controls.Clear()
         End If
      End If
   End Sub

   Private Sub pCalcularTotales(ByVal vdvwDatos As DataView, ByRef rdblPagado As Double, ByRef rdblDeuda As Double, ByRef rintCantidad As Integer)
      Dim drFila As DataRowView
      For Each drFila In vdvwDatos
         If CheckInt(drFila("Periodo")) <> 0 Then
            rdblPagado += CDbl(drFila("PAGADO"))
            rdblDeuda += CDbl(drFila("SALDO"))
            rintCantidad += 1
         End If
      Next
      drFila = Nothing
   End Sub

   Private Sub pMostrarPie()
      Dim oBLL As New ConsultasVarias
      Dim dsParametros As DataSet

      Me.lblFechaHora.Text = GetFecha() + " " + Date.Now.ToString("HH:mm")
      dsParametros = oBLL.ParametrosReportes(GetConexionSiatTributosLinea, GetMuniID)
      If dsParametros.Tables(0).Rows.Count > 0 Then
         Me.lblPagos.Text = CheckStr(dsParametros.Tables(0).Rows(0)(3))
         Me.lblConsultas.Text = CheckStr(dsParametros.Tables(0).Rows(0)(5))
      End If
      dsParametros = Nothing
      oBLL = Nothing

   End Sub
End Class
