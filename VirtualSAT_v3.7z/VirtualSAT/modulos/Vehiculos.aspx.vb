Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb

Partial Class Vehiculos
    Inherits PageBase
    Private mintCodigoUsuario As Integer

    Protected Sub Page_Load1(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'mintCodigoUsuario = FuncionesWeb.GetCodigoUsuario
        If Not IsPostBack Then
            Inicio()
        End If
    End Sub

    Private Sub Inicio()
        Dim oBLL As New ConsultasVarias
        Dim ds As DataSet
        ds = oBLL.BuscarDJVehicularContribuyente(GetConexionSiatTributos, mintCodigoUsuario)
        If Not ds Is Nothing Then
            Me.grdVehiculos.DataSource = ds.Tables(0)
            Me.grdVehiculos.DataBind()
        End If
        oBLL = Nothing
    End Sub

End Class
