Option Explicit On
Option Strict On

Imports SAT
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.Funciones.Validaciones
Imports SAT.HomeSiteBLL
Imports SAT.SeguridadSAT.Encriptacion

Partial Class modulos_VerMisPagos
    Inherits System.Web.UI.Page

    Private mstrUsuario As String = ""

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        mstrUsuario = GetCodigoUsuario()
        If Not IsPostBack Then
            Inicio()
            RegistroAccesoPagina(GetConexionSoporteWEB, Request.CurrentExecutionFilePath)
        End If
    End Sub

    Private Sub Inicio()
        Dim oBLL As New ConsultasWeb
        Dim ds As DataSet

        Me.lblTitulo.Text = "MIS  PAGOS  VIRTUALES"

        ds = oBLL.PagosVirtualesBuscarPagosxUsuario(GetConexionPagosVirtuales, mstrUsuario)
        If Not ds Is Nothing Then
            Me.grdMisPagos.DataSource = ds.Tables(0)
            Me.grdMisPagos.DataBind()
        End If
        ds = Nothing
        oBLL = Nothing

    End Sub
End Class
