﻿Option Explicit On
Option Strict On

Imports System.Data.SqlClient
Imports System.Data
Imports FuncionesWeb
Imports FuncionesCarrito
Imports SAT.HomeSiteBLL
Imports SAT.Funciones.Validaciones


Partial Class frmRegistrarDIC
    Inherits System.Web.UI.Page

    Private strNameCnxSIAT001 As String = "BDSIAT001"
    Private strNameCnxSIAT002 As String = "BDSIAT002"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            pInicio()
        End If
    End Sub
    Private Sub pInicio()
        'ddlCodigoInfLetra.Attributes.Add("onChange", "MostrarTxtCodigoInfLetra();")
        fctrl_BuscarControl("divResumen").Visible = False

        ddlCodigoInfSufijo.Enabled = False
        ddlCodigoInfSufijo.Items.Add("")
        ddlCodigoInfSufijo.Items.Add("a")
        ddlCodigoInfSufijo.Items.Add("b")
        ddlCodigoInfSufijo.SelectedIndex = 0

        pValidarUsuarioSesion()   '<<<<<<<<<<<<<<<<<<<
    End Sub
    ''' ///////////////////////////////////////////// LOGIN ///////////////////////////////////////////////////////////
    Private Sub pValidarUsuarioSesion()
        Dim intCodUsuWeb As Integer = GetCodigoRegistroUsuario()
        Dim dsUsuario As DataSet
        'Dim strIP As String = Request.ServerVariables("REMOTE_HOST")

        intCodUsuWeb = 1234   '<<<<<<<<<<<<<<<<<<<< TEST-QUITAR

        If intCodUsuWeb <= 1 Then
            pMuestraOcultaDivs(True)
        Else
            Using oBLL As New ConsultasWeb
                dsUsuario = oBLL.BuscarUsuarioWEB(GetConexionSoporteWEB, intCodUsuWeb, "", "")
                If dsUsuario.Tables(0).Rows.Count > 0 Then
                    'pMostrarDatosUsuario(dsUsuario.Tables(0))
                    pMuestraOcultaDivs(False)
                    divResumen.Visible = False
                    Return   '<<<<<<<<<<<<<<<<<<<< TEST-QUITAR
                    Dim strCorreo As String = CStr(Session.Item("email"))

                    If pValidarCorreoSospechoso(strCorreo) = 1 Then
                        Me.lblMensajeSospechoso.Text = "Mensaje: El correo " + strCorreo + " se encuentra en observación por el operador de la tarjeta."
                        Me.lblMensajeLogin.ForeColor = Drawing.Color.Red
                        btnPagar.Visible = False
                        pOcultarTodo()
                        lblMensajeSospechoso.Visible = True
                        Me.lblMensajeSospechoso.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End If

                End If

            End Using
        End If
    End Sub
    Private Sub pMuestraOcultaDivs(ByVal vbolEstado As Boolean)
        Me.divAuteticaDatos.Visible = vbolEstado
        Me.divRegistrar.Visible = Not vbolEstado
        Me.divResumen.Visible = Not vbolEstado
        'Me.divFormaPago.Visible = Not vbolEstado
    End Sub

    Protected Function pValidarCorreoSospechoso(ByVal sCorreo As String) As Integer
        Dim validaOK As Integer = 0
        Dim dsUsuario As New DataSet
        Dim strCorreo As String
        Dim strIP As String = Request.ServerVariables("REMOTE_HOST")

        If txtEmailLogin.Text = "" Then
            strCorreo = CStr(Session.Item("email"))
        Else
            strCorreo = ValidaCorreo(Me.txtEmailLogin.Text)
        End If

        Using oBLL As New SAT.HomeSiteBLL.ConsultasWeb
            dsUsuario = oBLL.ConsultarCorreoSospechoso(GetConexionPagosVirtuales, strCorreo)
            If dsUsuario.Tables(0).Rows.Count > 0 Then
                validaOK = 1
            End If

        End Using

        dsUsuario = Nothing
        Return validaOK

    End Function
    Shared Function ValidaCorreo(ByVal vstrCadena As String) As String
        If vstrCadena Is Nothing Or vstrCadena Is DBNull.Value Then
            Return ""
        End If
        vstrCadena = vstrCadena.Replace("'", "")
        vstrCadena = vstrCadena.Replace("--", "")
        vstrCadena = vstrCadena.Replace("&", "")
        vstrCadena = vstrCadena.Replace("""", "")
        vstrCadena = vstrCadena.Replace("%", "")
        vstrCadena = vstrCadena.Replace("#", "")
        Return vstrCadena.Trim
    End Function
    Private Sub pOcultarTodo()
        Me.divAuteticaDatos.Visible = False
        'Me.divAutenticaTexto.Visible = False
        'Me.divFormaPago.Visible = False
    End Sub
    ''' ///////////////////////////////////////////// FIN - LOGIN ///////////////////////////////////////////////////////////


    Protected Sub btnSiguiente_Click(sender As Object, e As EventArgs) Handles btnSiguiente.Click

        'Dim strNumDocS As String
        Dim strPlaca As String
        Dim strFechaInf As String
        Dim strFechaNoti As String
        Dim strCodigoInf As String
        Dim strNumLic As String
        Dim strFechaReval As String

        Dim shCodMun As Int16 = 1
        Dim strNumDocS As String = txtNumDocS.Text.Trim
        Dim strEstadoPapeleta As String = ""
        Dim strPlacaPapeleta As String = ""
        Dim strDocImpCargo As String = ""
        Dim strCodInfraccion As String = ""
        Dim strImportePagado As String = ""
        Dim strFechaPago As String = ""
        Dim strEstadoMensaje As String = ""

        Dim dtTabla As New DataTable
        dtTabla = fdta_Papeleta_BuscarEstado(shCodMun, strNumDocS)

        'Validar Estado
        If dtTabla.Rows.Count > 0 Then
            strEstadoPapeleta = dtTabla.Rows(0)(3).ToString
            strPlacaPapeleta = dtTabla.Rows(0)(4).ToString
            strDocImpCargo = dtTabla.Rows(0)(5).ToString
            strCodInfraccion = dtTabla.Rows(0)(6).ToString
            strImportePagado = dtTabla.Rows(0)(7).ToString
            strFechaPago = dtTabla.Rows(0)(8).ToString

            If strEstadoPapeleta = "Cancelado" Then
                strEstadoMensaje = "El número de papeleta " + strNumDocS + " no registra deuda pendiente<br>"
                strEstadoMensaje = strEstadoMensaje + "Placa del vehículo infractor: " + strPlacaPapeleta + "<br>"
                strEstadoMensaje = strEstadoMensaje + "N° documento de imputación de cargo: " + strDocImpCargo + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Código de infracción: " + strCodInfraccion + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Importe pagado: " + strImportePagado + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Fecha de pago: " + strFechaPago
            End If

            If strEstadoPapeleta = "Anulado" Then
                strEstadoMensaje = "El número de papeleta " + strNumDocS + " se encuentra anulado para mayor información comuníquese con AlóSAT al teléfono 315-2400 o al correo asuservicio@sat.gob.pe"
            End If

            If strEstadoPapeleta = "Pendiente" Then
                'RN003 - Para los documentos en estado “Pendiente”, se direccionará al resultado de la consulta de papeletas.
            End If

            If strEstadoPapeleta = "Pagado" Then
                strEstadoMensaje = "El número de papeleta " + strNumDocS + " no registra deuda pendiente<br>"
                strEstadoMensaje = strEstadoMensaje + "Placa del vehículo infractor: " + strPlacaPapeleta + "<br>"
                strEstadoMensaje = strEstadoMensaje + "N° documento de imputación de cargo: " + strDocImpCargo + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Código de infracción: " + strCodInfraccion + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Importe pagado: " + strImportePagado + "<br>"
                strEstadoMensaje = strEstadoMensaje + "Fecha de pago: " + strFechaPago
            End If

            If strEstadoPapeleta = "Registrado" Then
                strEstadoMensaje = "La operación de pago  de la papeleta " + strNumDocS + " se encuentra pendiente de confirmación, para mayor información comuníquese con su operador bancario"
            End If

            lblMensaje.Text = strEstadoMensaje
            Exit Sub
        End If

        'Validar Código de infracción
        Dim strCodigoInfLetra As String = txtCodigoInfLetra.Text.Trim
        Dim strCodigoInfNumero As String = txtCodigoInfNumero.Text.Trim
        Dim strCodigoInfSufijo As String = ddlCodigoInfSufijo.SelectedValue.Trim
        Dim strCodigoInfLetraNumero As String = strCodigoInfLetra + strCodigoInfNumero

        Dim strFechaInfraccion As String = txtFechaInf.Text.Trim
        Dim dtFechaInfraccion As Date = Convert.ToDateTime(strFechaInfraccion)

        Dim dtFechaMenor As Date = Convert.ToDateTime("31/12/2019")
        Dim dtFechaMayor As Date = Convert.ToDateTime("01/01/2019")

        'Validación Código Infracción Letra
        If strNumDocS.Length > 0 AndAlso (strNumDocS.Substring(0, 1) = "E" Or IsNumeric(strNumDocS)) Then
            If Not (strCodigoInfLetra.Substring(0, 1) = "M" Or strCodigoInfLetra.Substring(0, 1) = "G" Or strCodigoInfLetra.Substring(0, 1) = "L") Then
                strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                lblMensaje.Text = strEstadoMensaje
                Exit Sub
            End If
        End If

        If strNumDocS.Length > 0 AndAlso (strNumDocS.Substring(0, 1) = "C" Or _
                                          strNumDocS.Substring(0, 2) = "CE" Or _
                                          strNumDocS.Substring(0, 1) = "I") Then

            If dtFechaInfraccion <= dtFechaMenor Then 'menor o igual al 31 de diciembre de 2019

                If Not (strCodigoInfLetra.Substring(0, 1) = "N" Or _
                        strCodigoInfLetra.Substring(0, 1) = "R" Or _
                        strCodigoInfLetra.Substring(0, 1) = "E" Or _
                        strCodigoInfLetra.Substring(0, 1) = "U" Or _
                        strCodigoInfLetra.Substring(0, 1) = "V" Or _
                        strCodigoInfLetra.Substring(0, 1) = "Z") Then
                    strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                End If

                If dtFechaInfraccion >= dtFechaMayor Then 'mayor o igual al 01 de enero de 2019
                    strEstadoMensaje = String.Empty
                    If Not (strCodigoInfLetra.Substring(0, 1) = "U" Or _
                            strCodigoInfLetra.Substring(0, 1) = "V") Then
                        strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                    End If
                End If
            Else
                If dtFechaInfraccion >= dtFechaMayor Then 'mayor o igual al 01 de enero de 2019
                    If Not (strCodigoInfNumero.Substring(0, 1) = "N" Or _
                            strCodigoInfNumero.Substring(0, 1) = "V") Then
                        strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                    End If
                End If
            End If

            If strEstadoMensaje.Length <> 0 Then
                lblMensaje.Text = strEstadoMensaje
                Exit Sub
            End If

        End If

        'Validación Código Infracción Número - SENSITIVA

        'Validación Código Infracción Sufijo
        If strCodigoInfLetraNumero = "G18" Or _
           strCodigoInfLetraNumero = "G31" Or _
           strCodigoInfLetraNumero = "G72" Then
            If Not (strCodigoInfSufijo = "a" Or _
                    strCodigoInfSufijo = "b") Then
                strEstadoMensaje = "El Código de Infracción no corresponde al Documento de Sanción"
                lblMensaje.Text = strEstadoMensaje
                Exit Sub
            End If
        End If

        'Nombre de la Falta
        Dim dtFalta As New DataTable

        Dim dtFechaRef As Date = Date.Now
        Dim iCodPPo As Int16 = 0
        Dim iCodTFo As Int16 = 0
        Dim strCodFal As String = strCodigoInfLetra + strCodigoInfNumero + strCodigoInfSufijo
        dtFalta = fdta_Infraccion_BuscarPorCodigo(dtFechaRef, iCodPPo, iCodTFo, strCodFal)

        If dtFalta.Rows.Count = 0 Then
            strEstadoMensaje = "El Código de Infracción no existe"
            lblMensaje.Text = strEstadoMensaje
            Exit Sub
        End If

        'Datos Personales
        strPlaca = txtPlaca.Text.Trim
        strFechaInf = txtFechaInf.Text.Trim
        strFechaNoti = txtFechaNoti.Text.Trim
        'If ddlCodigoInfSufijo.Enabled Then
        '    strCodigoInf = txtCodigoInfLetra.Text.Trim + txtCodigoInfNumero.Text.Trim + ddlCodigoInfSufijo.Text.Trim
        'Else
        '    strCodigoInf = txtCodigoInfLetra.Text.Trim + txtCodigoInfNumero.Text.Trim
        'End If
        strCodigoInf = txtCodigoInfLetra.Text.Trim + txtCodigoInfNumero.Text.Trim + ddlCodigoInfSufijo.Text.Trim
        strNumLic = txtNumLic.Text.Trim
        strFechaReval = txtFechaReval.Text.Trim

        lblNumDocSRes.Text = strNumDocS
        lblPlacaRes.Text = strPlaca
        lblFechaInfRes.Text = strFechaInf
        lblCodigoInfRes.Text = strCodigoInf + " - " + dtFalta.Rows(0)(5).ToString
        lblNumLicRes.Text = strNumLic

        'Calculo del Importe a Pagar
        'Dim ObjRE As New SAT.SIAT.COM.BLL.RE.Conciliacion.NX.Deuda ' ''coment-text-kgc
        Dim dtDeuda As DataTable

        Dim arrParam As New ArrayList
        'arrParam.Add(1) '@psiCodMun
        'arrParam.Add(strPaleta) '@pcPapele
        'arrParam.Add(strPlaca) '@pcPlaca
        'arrParam.Add(strFecInfraccion) '@psdFecInf
        'arrParam.Add(4) '@psiCodRgl
        'arrParam.Add(34) '@psiCodBLe
        'arrParam.Add(strFalta) '@pcCodFal
        'arrParam.Add(0) '@psiTipDiD
        'arrParam.Add("") '@pcDocIde
        'arrParam.Add(strLicencia) '@pcLicCon
        'arrParam.Add(strFecCalculo) '@psdFecCal
        'arrParam.Add(Convert.ToInt16(strArrAutUsu(0))) '@psiCodUsu 
        'arrParam.Add(strFecPago) '@psdFecPag
        'arrParam.Add(1) '@psiTipAge 
        'arrParam.Add(1) '@psiCodDPo
        'arrParam.Add(0) '@psiModo
        'arrParam.Add(0) '@piCantVehiculo
        'arrParam.Add("1") '@pcCalDescuento
        'arrParam.Add(Nothing) '@pcFecRevLicencia

        'dtDeuda = ObjRE.ConsultarDeudaDigitada(arrParam)  ''coment-text-kgc

        fctrl_BuscarControl("divRegistrar").Visible = False
        fctrl_BuscarControl("divResumen").Visible = True

    End Sub

    Protected Sub btnCorregir_Click(sender As Object, e As EventArgs) Handles btnCorregir.Click

        lblMensaje.Text = String.Empty
        fctrl_BuscarControl("divRegistrar").Visible = True
        fctrl_BuscarControl("divResumen").Visible = False

    End Sub

    Private Function fctrl_BuscarControl(ByVal pstrNameControl As String) As Control
        'Return FindControl(pstrNameControl)
        Return Master.FindControl("cplPrincipal").FindControl(pstrNameControl)
    End Function

    Private Function fbol_ValidarNumDocS() As Boolean
        Dim bolVal As Boolean = True

        Dim strNumDocS As String = txtNumDocS.Text.Trim()
        Dim strMensaje As String = String.Empty

        strMensaje = "Ingrese una Papeleta Válida"

        'Validacion RN002
        If strNumDocS.Length = 8 AndAlso IsNumeric(strNumDocS) Then
            strMensaje = String.Empty
        Else
            If strNumDocS.Length = 9 AndAlso (strNumDocS.Substring(0, 1) = "C" Or strNumDocS.Substring(0, 1) = "E") Then
                If IsNumeric(strNumDocS.Substring(1, 8)) Then
                    strMensaje = String.Empty
                End If
            Else
                If strNumDocS.Length = 10 AndAlso (strNumDocS.Substring(0, 2) = "CE") Then
                    If IsNumeric(strNumDocS.Substring(2, 8)) Then
                        strMensaje = String.Empty
                    End If
                Else
                    If strNumDocS.Length = 12 AndAlso (strNumDocS.Substring(0, 1) = "I") Then
                        strMensaje = String.Empty
                    End If
                End If
            End If
        End If

        If strMensaje.Length > 0 Then
            bolVal = False
        End If

        lblMensaje.Text = strMensaje
        Return bolVal
    End Function

    Protected Sub txtNumDocS_TextChanged(sender As Object, e As EventArgs) Handles txtNumDocS.TextChanged

        Dim strNumDocS As String = txtNumDocS.Text.Trim()
        ValidarNumDocSancion()

    End Sub

    'Protected Sub txtCodigoInfNumero_TextChanged(sender As Object, e As EventArgs) Handles txtCodigoInfNumero.TextChanged

    '    Dim strLetra = txtCodigoInfLetra.Text.Trim + txtCodigoInfNumero.Text.Trim

    '    If strLetra = "G18" Or strLetra = "G31" Or strLetra = "G72" Then
    '        ddlCodigoInfSufijo.Enabled = True
    '    Else
    '        ddlCodigoInfSufijo.Enabled = False
    '        ddlCodigoInfSufijo.SelectedIndex = 0
    '    End If

    'End Sub

    Private Function fbol_ValidarRegistro() As Boolean
        Dim bolVal As Boolean = True

        Dim strErrorNumDocS As String = lblErrorNumDocS.Text.Trim()
        Dim strErrorPlaca As String = lblErrorPlaca.Text.Trim()
        Dim strErrorFechaInf As String = lblErrorFechaInf.Text.Trim()
        Dim strErrorFechaNoti As String = lblErrorFechaNoti.Text.Trim()
        Dim strErrorCodigoInf As String = lblErrorCodigoInf.Text.Trim()
        Dim strErrorFechaReval As String = lblErrorFechaReval.Text.Trim()

        Return bolVal
    End Function

    Private Sub ValidarNumDocSancion()

        Dim script As String = "window.onload = function() { ValidarNumDocS(); };"
        ClientScript.RegisterStartupScript(Me.GetType(), "ValidarNumDocS", script, True)

        'Dim strErrorNumDocS As String = lblErrorNumDocS.Text
        'lblMensaje.Text = ""

        'Dim result1 As Int32 = Convert.ToInt32(hdfErrorNumDocS.Value)

        'If strErrorNumDocS <> String.Empty Then
        '    Exit Sub
        'End If

        Dim shCodMun As Int16 = 1
        Dim strNumDocS As String = txtNumDocS.Text.Trim()

        Dim dtTabla As New DataTable
        dtTabla = fdta_Papeleta_BuscarEstado(shCodMun, strNumDocS)

        If (dtTabla Is Nothing OrElse dtTabla.Rows.Count = 0) Then
            Exit Sub
        End If

        lblMensaje.Text = dtTabla.Rows(0)(3).ToString

    End Sub

    ''//////////////////////////////////// MIGRAR A COMPONENTES ///////////////////////////////////
    Private Function fdta_Papeleta_BuscarEstado(ByVal pshsiCodMun As Int16, ByVal pstrcPapele As String) As DataTable
        Dim dtTabla As New DataTable

        Dim cnCnx As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings(strNameCnxSIAT001).ConnectionString)
        cnCnx.Open()

        Dim cmd As SqlCommand = New SqlCommand("spRe_Papeleta_BuscarEstado", cnCnx)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@psiCodMun", pshsiCodMun)
        cmd.Parameters.AddWithValue("@pcPapele", pstrcPapele)

        Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
        da.Fill(dtTabla)

        Return dtTabla
    End Function

    Private Function fdta_Infraccion_BuscarPorCodigo(ByVal pdtFechaRef As Date, ByVal piCodPPo As Int16, ByVal piCodTFo As Int16, ByVal pstrCodFal As String) As DataTable
        Dim dtTabla As New DataTable

        Dim cnCnx As SqlConnection = New SqlConnection(ConfigurationManager.ConnectionStrings(strNameCnxSIAT001).ConnectionString)
        cnCnx.Open()

        Dim cmd As SqlCommand = New SqlCommand("spRe_Infraccion_BuscarPorCodigo", cnCnx)
        cmd.CommandType = CommandType.StoredProcedure
        cmd.Parameters.AddWithValue("@psdFechaRef", pdtFechaRef)
        cmd.Parameters.AddWithValue("@psiCodPPo", piCodPPo)
        cmd.Parameters.AddWithValue("@psiCodTFo", piCodTFo)
        cmd.Parameters.AddWithValue("@pcCodFal", pstrCodFal)

        Dim da As SqlDataAdapter = New SqlDataAdapter(cmd)
        da.Fill(dtTabla)

        Return dtTabla
    End Function
    ''//////////////////////////////////// FIN - MIGRAR A COMPONENTES ///////////////////////////////////
End Class
