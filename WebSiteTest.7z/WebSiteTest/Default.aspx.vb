﻿
Imports System.Web.Services
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Data



Partial Class _Default
    Inherits System.Web.UI.Page


    <WebMethod()> _
    Public Shared Function GetCustomers(prefix As String) As String()
        Dim customers As New List(Of String)()
        Try

            Using conn As New SqlConnection()
                conn.ConnectionString = ConfigurationManager.ConnectionStrings("constr").ConnectionString
                Using cmd As New SqlCommand()
                    cmd.CommandText = "select ContactName, CustomerId from Customers where ContactName like @SearchText + '%'"
                    cmd.Parameters.AddWithValue("@SearchText", prefix)
                    cmd.Connection = conn
                    conn.Open()
                    Using sdr As SqlDataReader = cmd.ExecuteReader()
                        While sdr.Read()
                            customers.Add(String.Format("{0}-{1}", sdr("ContactName"), sdr("CustomerId")))
                        End While
                    End Using
                    conn.Close()
                End Using
            End Using
        Catch ex As Exception
            System.Console.WriteLine("Se genero un problema")

        End Try

        Return customers.ToArray()
    End Function


    '<System.Web.Services.WebMethod(EnableSession:=True)> _
    <System.Web.Services.WebMethod()> _
    Public Shared Function checkUserName(ByVal IDVal As String) As String
        Dim result As String = String.Empty
        Dim conString As String = System.Configuration.ConfigurationManager.ConnectionStrings("constr2").ConnectionString 'System.Configuration.ConfigurationManager.ConnectionStrings("AdventureWorks2008R2ConnectionString2").ConnectionString
        Dim qry As String = "Select AddressID from Person.Address Where AddressID =@AddressID"
        Dim da As SqlDataAdapter = New SqlDataAdapter(qry, conString)
        da.SelectCommand.Parameters.AddWithValue("@AddressID", IDVal.Trim())
        Dim ds As DataSet = New DataSet()
        da.Fill(ds, "IDTable")

        If ds.Tables("IDTable").Rows.Count > 0 Then
            result = "ID already in use"
        Else
            result = "ID is available, you can use it"
        End If

        Return result
    End Function

    Protected Sub Submit(sender As Object, e As EventArgs)
        Dim customerName As String = Request.Form(txtSearch.UniqueID)
        Dim customerId As String = Request.Form(hfCustomerId.UniqueID)
        ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Name: " & customerName & "\nID: " & customerId & "');", True)
    End Sub


End Class
