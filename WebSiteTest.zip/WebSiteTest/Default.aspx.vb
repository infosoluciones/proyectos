﻿
Imports System.Web.Services
Imports System.Configuration
Imports System.Data.SqlClient



Partial Class _Default
    Inherits System.Web.UI.Page


    <WebMethod()> _
    Public Shared Function GetCustomers(prefix As String) As String()
        Dim customers As New List(Of String)()
        Using conn As New SqlConnection()
            conn.ConnectionString = ConfigurationManager.ConnectionStrings("constr").ConnectionString
            Using cmd As New SqlCommand()
                cmd.CommandText = "select ContactName, CustomerId from Customers where ContactName like @SearchText + '%'"
                cmd.Parameters.AddWithValue("@SearchText", prefix)
                cmd.Connection = conn
                conn.Open()
                Using sdr As SqlDataReader = cmd.ExecuteReader()
                    While sdr.Read()
                        customers.Add(String.Format("{0}-{1}", sdr("ContactName"), sdr("CustomerId")))
                    End While
                End Using
                conn.Close()
            End Using
        End Using
        Return customers.ToArray()
    End Function

    Protected Sub Submit(sender As Object, e As EventArgs)
        Dim customerName As String = Request.Form(txtSearch.UniqueID)
        Dim customerId As String = Request.Form(hfCustomerId.UniqueID)
        ClientScript.RegisterStartupScript(Me.GetType(), "alert", "alert('Name: " & customerName & "\nID: " & customerId & "');", True)
    End Sub


End Class
